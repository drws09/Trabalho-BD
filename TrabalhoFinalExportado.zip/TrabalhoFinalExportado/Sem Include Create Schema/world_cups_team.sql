-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id_team` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `confederation` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `participations` smallint DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `wins` smallint DEFAULT NULL,
  `draws` smallint DEFAULT NULL,
  `losses` smallint DEFAULT NULL,
  `goals_scored` smallint DEFAULT NULL,
  `goals_against` smallint DEFAULT NULL,
  PRIMARY KEY (`id_team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (0,'Romania','UEFA',7,21,8,5,8,30,32),(1,'Switzerland','UEFA',12,37,12,8,17,50,64),(2,'USA','CONCACAF',11,33,8,6,19,37,62),(3,'Colombia','CONMEBOL',6,22,9,3,10,32,30),(4,'Brazil','CONMEBOL',22,109,73,18,18,229,105),(5,'Sweden','UEFA',12,51,19,13,19,80,73),(6,'Russia','UEFA',11,45,19,10,16,77,54),(7,'Cameroon','CAF',8,23,4,7,12,18,43),(8,'Germany','UEFA',20,109,67,20,22,226,125),(9,'Spain','UEFA',16,63,30,15,18,99,72),(10,'South Korea','AFC',11,34,6,9,19,34,70),(11,'Bolivia','CONMEBOL',3,6,0,1,5,1,20),(12,'Nigeria','CAF',6,21,6,3,12,23,30),(13,'Bulgaria','UEFA',7,26,3,8,15,22,53),(14,'Argentina','CONMEBOL',18,81,43,15,23,137,93),(15,'Greece','UEFA',3,10,2,2,6,5,20),(16,'Mexico','CONCACAF',17,57,16,14,27,60,98),(17,'Ireland','UEFA',3,13,2,8,3,10,10),(18,'Italy','UEFA',18,83,45,21,17,128,77),(19,'Norway','UEFA',3,8,2,3,3,7,8),(20,'Netherlands','UEFA',11,50,27,12,11,86,48),(21,'Saudi Arabia','AFC',6,16,3,2,11,11,39),(22,'Belgium','UEFA',14,48,20,9,19,68,72),(23,'Morocco','CAF',6,16,2,5,9,14,22),(24,'Scotland','UEFA',8,23,4,7,12,25,41),(25,'Chile','CONMEBOL',9,33,11,7,15,40,49),(26,'Austria','UEFA',7,29,12,4,13,43,47),(27,'France','UEFA',16,66,34,13,19,120,77),(28,'Denmark','UEFA',6,20,9,5,6,30,26),(29,'South Africa','CAF',3,9,2,4,3,11,16),(30,'Paraguay','CONMEBOL',8,27,7,10,10,30,38),(31,'Serbia','UEFA',13,46,18,8,20,66,63),(32,'Iran','AFC',6,15,2,4,9,9,24),(33,'England','UEFA',16,69,29,21,19,91,64),(34,'Tunisia','CAF',6,15,2,4,9,13,25),(35,'Croatia','UEFA',6,23,11,4,8,35,26),(36,'Jamaica','CONCACAF',1,3,1,0,2,3,9),(37,'Japan','AFC',7,21,5,5,11,20,29),(38,'Senegal','CAF',3,8,3,3,2,11,10),(39,'Uruguay','CONMEBOL',14,56,24,12,20,87,74),(40,'Slovenia','UEFA',2,6,1,1,4,5,10),(41,'Turkey','UEFA',2,10,5,1,4,20,17),(42,'Costa Rica','CONCACAF',6,18,5,5,8,19,28),(43,'China','AFC',1,3,0,0,3,0,9),(44,'Portugal','UEFA',8,30,14,6,10,49,35),(45,'Poland','UEFA',9,34,16,5,13,46,45),(46,'Ecuador','CONMEBOL',4,10,4,1,5,10,11),(47,'Trinidad and Tobago','CONCACAF',1,3,0,1,2,0,4),(48,'Ivory Coast','CAF',3,9,3,1,5,13,14),(50,'Angola','CAF',1,3,0,2,1,1,2),(51,'Ghana','CAF',4,12,4,3,5,13,16),(52,'Czech Republic','UEFA',9,33,12,5,16,47,49),(53,'Australia','AFC',6,16,2,4,10,13,31),(54,'Togo','CAF',1,3,0,0,3,1,6),(55,'Ukraine','UEFA',1,5,2,1,2,5,7),(56,'Peru','CONMEBOL',5,18,5,3,10,21,33),(57,'Hungary','UEFA',9,32,15,3,14,87,57);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:46
