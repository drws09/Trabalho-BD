-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `golden_boot`
--

DROP TABLE IF EXISTS `golden_boot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `golden_boot` (
  `id_golden_boot` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `goals` smallint DEFAULT NULL,
  PRIMARY KEY (`id_golden_boot`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `golden_boot_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `golden_boot_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `golden_boot`
--

LOCK TABLES `golden_boot` WRITE;
/*!40000 ALTER TABLE `golden_boot` DISABLE KEYS */;
INSERT INTO `golden_boot` VALUES (0,0,54,4,8),(1,1,55,4,5),(2,2,56,4,7),(3,3,57,6,9),(4,4,58,5,11),(5,5,59,6,13),(6,6,60,6,4),(7,6,61,6,4),(8,6,62,6,4),(9,6,63,6,4),(10,6,64,3,4),(11,6,65,4,4),(12,7,66,6,9),(13,8,13,6,10),(14,9,67,7,7),(15,10,21,7,6),(16,11,17,7,6),(17,12,68,5,6),(18,13,32,7,6),(19,14,69,3,6),(20,14,48,7,6),(21,15,41,7,6),(22,16,0,7,8),(23,17,70,7,5),(24,18,44,6,5),(25,19,71,5,6),(26,20,72,6,6);
/*!40000 ALTER TABLE `golden_boot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:46
