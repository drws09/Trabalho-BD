CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `2002_wc_finalists_campaigns_view`
--

DROP TABLE IF EXISTS `2002_wc_finalists_campaigns_view`;
/*!50001 DROP VIEW IF EXISTS `2002_wc_finalists_campaigns_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `2002_wc_finalists_campaigns_view` AS SELECT 
 1 AS `STAGE`,
 1 AS `DATA`,
 1 AS `Stadium`,
 1 AS `Match Result`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `2002_wc_r9_goals_2_view`
--

DROP TABLE IF EXISTS `2002_wc_r9_goals_2_view`;
/*!50001 DROP VIEW IF EXISTS `2002_wc_r9_goals_2_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `2002_wc_r9_goals_2_view` AS SELECT 
 1 AS `DESCRIPTION`,
 1 AS `MINUTOS DOS GOLS`,
 1 AS `OPPONENT`,
 1 AS `FINAL SCORE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `2002_wc_top_goalscorers_view`
--

DROP TABLE IF EXISTS `2002_wc_top_goalscorers_view`;
/*!50001 DROP VIEW IF EXISTS `2002_wc_top_goalscorers_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `2002_wc_top_goalscorers_view` AS SELECT 
 1 AS `PLAYER`,
 1 AS `TEAM`,
 1 AS `GOALS`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `best_young_player`
--

DROP TABLE IF EXISTS `best_young_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `best_young_player` (
  `id_best_young_player` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  PRIMARY KEY (`id_best_young_player`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `best_young_player_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `best_young_player_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `best_young_player`
--

LOCK TABLES `best_young_player` WRITE;
/*!40000 ALTER TABLE `best_young_player` DISABLE KEYS */;
INSERT INTO `best_young_player` VALUES (0,5,10),(1,6,64),(2,7,97),(3,8,86),(4,9,106),(5,10,107),(6,11,108),(7,12,109),(8,13,110),(9,14,111),(10,15,112),(11,16,113),(12,17,114),(13,18,44),(14,19,8),(15,20,9),(16,4,NULL),(17,3,NULL),(18,2,NULL),(19,1,NULL),(20,0,NULL);
/*!40000 ALTER TABLE `best_young_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `boot_winners`
--

DROP TABLE IF EXISTS `boot_winners`;
/*!50001 DROP VIEW IF EXISTS `boot_winners`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `boot_winners` AS SELECT 
 1 AS `WORLD CUP`,
 1 AS `GOLDEN BOOT`,
 1 AS `SILVER SHOE`,
 1 AS `BRONZE SHOE`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `bronze_ball`
--

DROP TABLE IF EXISTS `bronze_ball`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bronze_ball` (
  `id_Bronze_Ball` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  PRIMARY KEY (`id_Bronze_Ball`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `bronze_ball_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `bronze_ball_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bronze_ball`
--

LOCK TABLES `bronze_ball` WRITE;
/*!40000 ALTER TABLE `bronze_ball` DISABLE KEYS */;
INSERT INTO `bronze_ball` VALUES (0,10,46),(1,11,47),(2,12,NULL),(3,13,31),(4,14,48),(5,15,49),(6,16,50),(7,17,51),(8,18,52),(9,19,53),(10,20,7),(11,9,NULL),(12,8,NULL),(13,7,NULL),(14,6,NULL),(15,5,NULL),(16,4,NULL),(17,3,NULL),(18,2,NULL),(19,1,NULL),(20,0,NULL);
/*!40000 ALTER TABLE `bronze_ball` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bronze_shoe`
--

DROP TABLE IF EXISTS `bronze_shoe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bronze_shoe` (
  `id_Bronze_Shoe` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `goals` smallint DEFAULT NULL,
  PRIMARY KEY (`id_Bronze_Shoe`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `bronze_shoe_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `bronze_shoe_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bronze_shoe`
--

LOCK TABLES `bronze_shoe` WRITE;
/*!40000 ALTER TABLE `bronze_shoe` DISABLE KEYS */;
INSERT INTO `bronze_shoe` VALUES (0,0,94,3,3),(1,1,NULL,NULL,NULL),(2,2,NULL,NULL,NULL),(3,3,95,6,5),(4,4,NULL,NULL,NULL),(5,5,NULL,NULL,NULL),(6,6,NULL,NULL,NULL),(7,7,96,3,4),(8,7,97,6,4),(9,7,98,4,4),(10,7,99,3,4),(11,8,86,4,5),(12,9,NULL,NULL,NULL),(13,10,100,7,5),(14,11,101,5,4),(15,12,NULL,NULL,NULL),(16,13,102,5,4),(17,14,33,7,5),(18,14,103,7,5),(19,15,NULL,NULL,NULL),(20,16,NULL,NULL,NULL),(21,17,0,5,3),(22,18,43,7,5),(23,19,104,5,4),(24,20,105,6,4);
/*!40000 ALTER TABLE `bronze_shoe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `id_city` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  PRIMARY KEY (`id_city`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `city_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `country` (`id_host`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (0,'Berlin',3),(1,'Munich',3),(2,'Dortmund',3),(3,'Sttutgart',3),(4,'Gelsenkirchen',3),(5,'Hamburg',3),(6,'Frankfurt',3),(7,'Kaiserslautern',3),(8,'Cologne',3),(9,'Hannover',3),(10,'Leipzig',3),(11,'Nuremberg',3),(12,'Daegu',2),(13,'Seoul',2),(14,'Busan',2),(15,'Incheon',2),(16,'Ulsan',2),(17,'Suwon',2),(18,'Gwangju',2),(19,'Jeonju',2),(20,'Seogwipo',2),(21,'Daejeon',2),(22,'Yokohama',2),(23,'Saitama',2),(24,'Shizuoka',2),(25,'Osaka',2),(26,'Miyagi',2),(27,'Oita',2),(28,'Niigata',2),(29,'Kashima',2),(30,'Kobe',2),(31,'Sapporo',2),(32,'Saint-Denis',1),(33,'Marseille',1),(34,'Paris',1),(35,'Lyon',1),(36,'Lens',1),(37,'Nantes',1),(38,'Toulouse',1),(39,'Saint-Etienne',1),(40,'Bordeaux',1),(41,'Montpellier',1),(42,'Pasadena',0),(43,'Stanford',0),(44,'Pontiac',0),(45,'East Rutherford',0),(46,'Dallas',0),(47,'Chicago',0),(48,'Orlando',0),(49,'Foxborough',0),(50,'Washington DC',0),(51,'Johannesburg',4),(52,'Rio de Janeiro',5),(53,'Moscow',6),(54,'Rome',7),(55,'Mexico City',8),(56,'Madrid',9),(57,'Buenos Aires',10),(58,'London',11),(59,'Santiago',12),(60,'Solna',13),(61,'Bern',14),(62,'Colombes',1),(63,'Montevideo',15),(64,'Turin',7),(65,'Naples',7),(66,'Florence',7);
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coach`
--

DROP TABLE IF EXISTS `coach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coach` (
  `id_coach` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nationality` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `participations` smallint DEFAULT NULL,
  `titles` smallint DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `wins` smallint DEFAULT NULL,
  `draws` smallint DEFAULT NULL,
  `losses` smallint DEFAULT NULL,
  `goals_scored` smallint DEFAULT NULL,
  `goals_against` smallint DEFAULT NULL,
  PRIMARY KEY (`id_coach`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coach`
--

LOCK TABLES `coach` WRITE;
/*!40000 ALTER TABLE `coach` DISABLE KEYS */;
INSERT INTO `coach` VALUES (0,'Rudi Voller','Germany',1,0,7,5,1,1,14,3),(1,'Luis Felipe Scolari','Brazil',3,1,21,14,3,4,36,23),(2,'Marcello Lippi','Italy',2,1,10,5,4,1,16,7),(3,'Raymond Domenech','France',2,0,10,4,4,2,10,7),(4,'Bert van Marwijk','Netherlands',2,0,10,6,1,3,14,11),(5,'Vicente del Bosque','Spain',2,1,10,7,0,3,12,9),(6,'Joachim Low','Germany',3,1,17,12,1,4,36,13),(7,'Alejandro Sabella','Argentina',1,0,7,5,1,1,8,4),(8,'Didier Deschamps','France',2,1,12,9,2,1,24,9),(9,'Zlatko Dalic','Croatia',1,0,7,4,2,1,14,9),(10,'Arrigo Sacchi','Italy',1,0,7,4,2,1,8,5),(11,'Aime Jaquet','France',1,1,7,6,1,0,15,2),(12,'Carlos Alberto Parreira','Brazil',6,1,23,10,4,9,28,32),(13,'Maio Jorge Lobo Zagallo','Brazil',3,1,20,13,3,4,39,21),(14,'Franz Beckenbauer','Germany',2,1,14,8,4,2,23,12),(15,'Carlos Bilardo','Argentina',2,1,14,8,4,2,19,9),(16,'Enzo Bearzot','Italy',3,1,17,9,5,3,26,18),(17,'Jupp Derwall','Germany',1,0,7,3,2,2,12,10),(18,'Cesar Luis Menotti','Argentina',3,1,17,7,3,7,28,22),(19,'Ernst Happel','Austria',1,0,7,3,2,2,15,10),(20,'Rinus Michels','Netherlands',1,0,7,5,1,1,15,3),(21,'Helmut Schon','Germany',4,1,19,14,1,4,51,23),(22,'Ferruccio Valcareggi','Italy',3,0,10,4,3,3,15,13),(23,'Alf Ramsey','England',2,1,10,7,1,2,15,7),(24,'Aymore Moreira','Brazil',1,1,6,5,1,0,14,5),(25,'Rudolf Vytlacil','Czech Republic',2,0,9,3,1,5,8,15),(26,'Vicente Feola','Brazil',1,1,6,5,1,0,16,4),(27,'George Raynor','England',2,0,10,5,2,3,20,21),(28,'Sepp Herberger','Germany',4,1,10,6,1,3,26,20),(29,'Gusztav Sebes','Hungary',1,0,5,4,0,1,27,10),(30,'Juan Lopez','Uruguay',2,1,9,6,1,2,31,14),(31,'Flavio Costa','Brazil',1,0,6,4,1,1,22,6),(32,'Vittorio Pozzo','Italy',2,2,9,8,1,0,23,8),(33,'Karoly Dietz','Hungary',1,0,4,3,0,1,15,5),(34,'Karel Petru','Czech Republic',1,0,4,3,0,1,9,6),(35,'Alberto Suppici','Uruguay',1,1,4,4,0,0,15,3),(36,'Francisco Olazar','Argentina',1,0,5,4,0,1,18,9),(37,'Senol Gunes','Turkey',1,0,7,4,1,2,10,6),(38,'Bora Milutinovic','Serbia',5,0,20,8,3,9,19,30),(39,'Alexandre Guimaraes','Costa Rica',2,0,6,1,1,4,8,15),(40,'Robert Waseige','Belgium',1,0,4,1,2,1,6,7),(41,'Sven-Goran Eriksson','Sweden',3,0,13,6,5,2,16,8),(42,'Nasser Al-Johar','Saudi Arabia',1,0,3,0,0,3,0,12),(43,'Mick McCarthy','Ireland',1,0,4,1,3,0,6,3),(44,'Winfried Schafer','Germany',1,0,3,1,1,1,2,3),(45,'Cesare Maldini','Italy',2,0,9,4,3,2,14,10),(46,'Bruce Arena','United States of America',2,0,8,2,2,4,9,13),(47,'Guus Hiddink','Netherlands',3,0,18,7,6,5,26,19),(48,'Jurgen Klinsmann','Germany',2,0,11,6,2,3,19,12),(49,'Ratomir Dujkovic','Serbia',1,0,4,2,0,2,4,6),(50,'Karel Bruckner','Czech Republic',1,0,3,1,0,2,3,4),(51,'Oleg Blokhin','Ukraine',1,0,5,2,1,2,5,7),(52,'Kobi Kuhn','Switzerland',1,0,4,2,2,0,4,0),(53,'Dick Advocaat','Netherlands',2,0,8,4,1,3,11,10),(54,'Otto Pfister','Germany',1,0,3,0,0,3,1,6),(55,'Luis Aragones','Spain',1,0,4,3,0,1,9,4),(56,'Jose Pekerman','Argentina',3,0,14,9,3,2,29,10),(57,'Ricardo La Volpe','Argentina',1,0,4,1,1,2,5,5),(58,'Jose Antonio Camacho','Spain',1,0,5,3,2,0,10,5),(59,'Bruno Metsu','France',1,0,5,2,2,1,7,6),(60,'Giovanni Trapattoni','Italy',1,0,4,1,1,2,5,5),(61,'Tommy Soderberg','Sweden',1,0,4,1,2,1,5,5),(62,'Daniel Passarella','Argentina',1,0,5,3,1,1,10,4),(63,'Glenn Hoddle','England',1,0,4,2,1,1,7,4),(64,'Paulo Cesar Carpegiani','Brazil',1,0,4,1,2,1,3,2),(65,'Tommy Svensson','Sweden',1,0,7,3,3,1,15,8),(66,'Anghel Iordanescu','Romania',2,0,9,5,2,2,14,12),(67,'Miguel Mejia Baron','Mexico',1,0,4,1,2,1,4,4),(68,'Dimitar Penev','Bulgaria',1,0,7,3,1,3,10,11),(69,'Clemens Westerhof','Netherlands',1,0,4,2,0,2,7,4),(70,'Bobby Robson','England',2,0,12,5,4,3,15,9),(71,'Azeglio Vicini','Italy',1,0,7,6,1,0,10,2),(72,'Ivica Osim','Bosnia and Herzegovina',1,0,5,3,1,1,8,6),(73,'Anibal Ruiz','Uruguay',1,0,3,1,0,2,2,2),(74,'Leo Beenhakker','Netherlands',2,0,7,0,4,3,3,8),(75,'Javier Clemente','Spain',2,0,8,3,3,2,18,10),(76,'Hristo Bonev','Bulgaria',1,0,3,0,1,2,1,7),(77,'Berti Vogts','Germany',2,0,10,6,2,2,17,13),(78,'Slobodan Sontrac','Yugoslavia',1,0,4,2,1,1,5,4),(79,'Philippe Troussier','France',2,0,7,2,3,2,8,9),(80,'Henri Michel','France',5,0,19,6,5,8,26,33),(81,'Egil Olsen','Norway',2,0,7,2,3,2,6,6),(82,'Craig Brown','Scotland',1,0,3,0,1,2,2,6),(83,'Antonio Oliveira','Portugal',1,0,3,1,0,2,6,4),(84,'Morten Olsen','Denmark',2,0,7,3,1,3,8,11),(85,'Diego Maradona','Argentina',1,0,5,4,0,1,10,6),(86,'Huh Jung-Moo','South Korea',1,0,4,1,1,2,6,8);
/*!40000 ALTER TABLE `coach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `id_host` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (0,'USA'),(1,'France'),(2,'Korea/Japan'),(3,'Germany'),(4,'South Africa'),(5,'Brazil'),(6,'Russia'),(7,'Italy'),(8,'Mexico'),(9,'Spain'),(10,'Argentina'),(11,'England'),(12,'Chile'),(13,'Sweden'),(14,'Switzerland'),(15,'Uruguay'),(16,'Catar'),(17,'Canada/Mexico/USA');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `every_goleada_view`
--

DROP TABLE IF EXISTS `every_goleada_view`;
/*!50001 DROP VIEW IF EXISTS `every_goleada_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `every_goleada_view` AS SELECT 
 1 AS `World Cup`,
 1 AS `STAGE`,
 1 AS `DATA`,
 1 AS `RESULT`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `extra_time`
--

DROP TABLE IF EXISTS `extra_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extra_time` (
  `id_extra_time` int NOT NULL,
  `game_id` int DEFAULT NULL,
  `home_score` smallint DEFAULT NULL,
  `away_score` smallint DEFAULT NULL,
  PRIMARY KEY (`id_extra_time`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `extra_time_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`id_game`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extra_time`
--

LOCK TABLES `extra_time` WRITE;
/*!40000 ALTER TABLE `extra_time` DISABLE KEYS */;
INSERT INTO `extra_time` VALUES (0,1,0,0),(1,2,0,1),(2,3,1,0),(3,6,0,0),(4,10,2,0),(5,13,2,0),(6,19,1,0),(7,40,0,2),(8,47,0,0),(9,48,0,0),(10,49,1,0),(11,50,0,0),(12,51,0,0),(13,52,0,1),(14,53,0,0),(15,54,1,0),(16,55,0,1),(17,56,0,0),(18,57,0,0),(19,58,0,0),(20,59,1,0),(21,60,1,1),(22,61,0,0),(23,62,0,1),(24,63,0,0),(25,64,0,0),(26,65,0,0);
/*!40000 ALTER TABLE `extra_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fair_play`
--

DROP TABLE IF EXISTS `fair_play`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fair_play` (
  `id_fair_play` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  PRIMARY KEY (`id_fair_play`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `team_id` (`team_id`),
  CONSTRAINT `fair_play_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `fair_play_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `team` (`id_team`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fair_play`
--

LOCK TABLES `fair_play` WRITE;
/*!40000 ALTER TABLE `fair_play` DISABLE KEYS */;
INSERT INTO `fair_play` VALUES (0,8,56),(1,9,8),(2,10,14),(3,11,4),(4,12,4),(5,13,33),(6,14,4),(7,15,33),(8,15,27),(9,16,22),(10,17,4),(11,17,9),(12,18,9),(13,19,3),(14,20,9),(15,7,NULL),(16,6,NULL),(17,5,NULL),(18,4,NULL),(19,3,NULL),(20,2,NULL),(21,1,NULL),(22,0,NULL);
/*!40000 ALTER TABLE `fair_play` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game` (
  `id_game` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `description` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data` date DEFAULT NULL,
  `stadium_id` int DEFAULT NULL,
  `attendance` int DEFAULT NULL,
  `referee_id` int DEFAULT NULL,
  `home_team_id` int DEFAULT NULL,
  `away_team_id` int DEFAULT NULL,
  `home_coach_id` int DEFAULT NULL,
  `away_coach_id` int DEFAULT NULL,
  `home_score` smallint DEFAULT NULL,
  `away_score` smallint DEFAULT NULL,
  PRIMARY KEY (`id_game`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `stadium_id` (`stadium_id`),
  KEY `referee_id` (`referee_id`),
  KEY `home_team_id` (`home_team_id`),
  KEY `away_team_id` (`away_team_id`),
  KEY `home_coach_id` (`home_coach_id`),
  KEY `away_coach_id` (`away_coach_id`),
  CONSTRAINT `game_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_2` FOREIGN KEY (`stadium_id`) REFERENCES `stadium` (`id_stadium`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_3` FOREIGN KEY (`referee_id`) REFERENCES `referee` (`id_referee`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_4` FOREIGN KEY (`home_team_id`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_5` FOREIGN KEY (`away_team_id`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_6` FOREIGN KEY (`home_coach_id`) REFERENCES `coach` (`id_coach`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_7` FOREIGN KEY (`away_coach_id`) REFERENCES `coach` (`id_coach`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
INSERT INTO `game` VALUES (0,16,'Final','2002-06-30',22,69029,0,8,4,0,1,0,2),(1,17,'Final','2006-07-09',0,69000,1,18,27,2,3,1,1),(2,18,'Final','2010-07-11',51,84490,2,20,9,4,5,0,0),(3,19,'Final','2014-07-13',52,74738,3,8,14,6,7,0,0),(4,20,'Final','2018-07-15',53,78011,4,27,35,8,9,4,2),(5,15,'Final','1998-07-12',32,75000,5,4,27,13,11,0,3),(6,14,'Final','1994-07-17',42,94194,6,4,18,12,10,0,0),(7,13,'Final','1990-07-08',54,73603,7,8,14,14,15,1,0),(8,12,'Final','1986-06-29',55,114600,8,14,8,15,14,3,2),(9,11,'Final','1982-07-11',56,90000,9,18,8,16,17,3,1),(10,10,'Final','1978-06-25',57,71483,10,14,20,18,19,1,1),(11,9,'Final','1974-07-07',58,75200,11,20,8,20,21,1,2),(12,8,'Final','1970-06-21',55,107412,12,4,18,13,22,4,1),(13,7,'Final','1966-07-30',59,96924,13,33,8,23,21,2,2),(14,6,'Final','1962-06-17',60,68679,14,4,52,24,25,3,1),(15,5,'Final','1958-06-29',61,49737,15,4,5,26,27,5,2),(16,4,'Final','1954-07-04',62,62500,16,8,57,28,29,3,2),(17,3,'Final *2nd Group Stage','1950-07-16',52,173850,17,39,4,30,31,2,1),(18,2,'Final','1938-06-19',63,45000,18,18,57,32,33,4,2),(19,1,'Final','1934-06-10',64,55000,19,18,52,32,34,1,1),(20,0,'Final','1930-07-30',65,68346,20,39,14,35,36,4,2),(21,16,'Group Stage (Group C)','2002-06-03',16,33842,21,4,41,1,37,2,1),(22,16,'Group Stage (Group C)','2002-06-08',20,36750,22,4,43,1,38,4,0),(23,16,'Group Stage (Group C)','2002-06-13',17,38524,23,42,4,39,1,2,5),(24,16,'Round of 16','2002-06-17',30,40440,24,4,22,1,40,2,0),(25,16,'Quarter Final','2002-06-21',24,47436,25,33,4,41,1,1,2),(26,16,'Semi Final','2002-06-26',23,61058,26,4,41,1,37,1,0),(27,16,'Group Stage (Group E)','2002-06-01',31,32218,27,8,21,0,42,8,0),(28,16,'Group Stage (Group E)','2002-06-05',29,35854,26,8,17,0,43,1,1),(29,16,'Group Stage (Group E)','2002-06-11',24,47085,28,7,8,44,0,0,2),(30,16,'Round of 16','2002-06-15',20,25176,29,8,30,0,45,1,0),(31,16,'Quarter Final','2002-06-21',16,37337,30,8,2,0,46,1,0),(32,16,'Semi Final','2002-06-25',13,65256,31,8,10,0,47,1,0),(33,16,'Third Place Match','2002-06-29',12,63483,32,10,41,47,37,2,3),(34,17,'Third Place Match','2006-07-08',3,52000,33,8,44,48,1,3,1),(35,17,'Group Stage (Group E)','2006-06-12',9,43000,34,18,51,2,49,2,0),(36,17,'Group Stage (Group E)','2006-06-17',7,46000,35,18,2,2,46,1,1),(37,17,'Group Stage (Group E)','2006-06-22',5,50000,36,52,18,50,2,0,2),(38,17,'Round of 16','2006-06-26',7,46000,37,18,53,2,47,1,0),(39,17,'Quarter Final','2006-06-30',5,50000,38,18,55,2,51,3,0),(40,17,'Semi Final','2006-07-04',2,65000,36,8,18,48,2,0,0),(41,17,'Group Stage - Group G','2006-06-13',3,52000,39,27,1,3,52,0,0),(42,17,'Group Stage - Group G','2006-06-18',10,43000,36,27,10,3,53,1,1),(43,17,'Group Stage - Group G','2006-06-23',8,45000,35,54,27,54,3,0,2),(44,17,'Round of 16','2006-06-27',9,43000,40,9,27,55,3,1,3),(45,17,'Quarter Final','2006-07-01',6,48000,37,4,27,12,3,0,1),(46,17,'Semi Final','2006-07-05',1,66000,35,44,27,1,3,0,1),(47,17,'Quarter Final','2006-06-30',0,72000,41,8,14,48,56,1,1),(48,17,'Quarter Final','2006-07-01',4,52000,1,33,44,1,41,0,0),(49,17,'Round of 16','2006-06-24',10,43000,42,14,16,56,57,1,1),(50,17,'Round of 16','2006-06-26',8,45000,36,1,55,52,51,0,0),(51,16,'Quarter Final','2002-06-22',18,42114,23,9,10,58,47,0,0),(52,16,'Quarter Final','2002-06-22',25,44233,43,38,41,59,37,0,0),(53,16,'Round of 16','2002-06-16',17,38926,22,9,17,58,43,1,1),(54,16,'Round of 16','2002-06-18',21,38588,44,10,18,47,60,1,1),(55,16,'Round of 16','2002-06-16',27,39747,27,5,38,61,59,1,1),(56,15,'Semi Final','1998-07-07',33,56200,45,4,20,13,47,1,1),(57,15,'Quarter Final','1998-07-03',32,77000,30,18,27,45,11,0,0),(58,15,'Round of 16','1998-06-30',39,30600,26,14,33,62,63,2,2),(59,15,'Round of 16','1998-06-28',36,31800,45,27,30,11,64,0,0),(60,14,'Quarter Final','1994-07-10',43,83500,46,0,5,66,65,1,1),(61,14,'Round of 16','1994-07-05',45,71030,47,16,13,67,68,1,1),(62,14,'Round of 16','1994-07-05',49,54367,48,12,18,69,10,1,1),(63,13,'Semi Final','1990-07-04',66,62628,49,8,33,14,70,1,1),(64,13,'Semi Final','1990-07-03',67,59978,50,18,14,71,15,1,1),(65,13,'Quarter Final','1990-06-30',68,38971,51,31,14,72,15,0,0),(66,17,'Group Stage (Group B)','2006-06-10',6,48000,52,33,30,41,73,1,0),(67,17,'Group Stage (Group B)','2006-06-20',7,46000,40,30,47,73,74,2,0),(68,16,'Group Stage (Group B)','2002-06-07',19,24000,23,9,30,58,45,3,1),(69,16,'Group Stage (Group D)','2002-06-05',17,37306,44,2,44,46,83,3,2),(70,15,'Group Stage (Group D)','1998-06-24',36,38100,53,9,13,75,76,6,1),(71,15,'Group Stage (Group F)','1998-06-21',36,38100,26,8,31,77,78,2,2),(72,15,'Group Stage (Group D)','1998-06-13',37,35500,54,9,12,75,38,2,3),(73,15,'Group Stage (Group C)','1998-06-12',33,55000,55,27,29,11,79,3,0),(74,15,'Group Stage (Group A)','1998-06-10',41,29800,56,23,19,80,81,2,2),(75,15,'Group Stage (Group A)','1998-06-10',32,80000,57,4,24,13,82,2,1),(76,18,'Group Stage (Group E)','2010-06-14',51,83465,58,20,28,4,84,2,0),(77,18,'Group Stage (Group B)','2010-06-17',51,82174,38,14,10,85,86,4,1);
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goal`
--

DROP TABLE IF EXISTS `goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goal` (
  `id_goal` int NOT NULL,
  `game_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `minuto` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_goal`),
  KEY `game_id` (`game_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `goal_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`id_game`) ON DELETE CASCADE,
  CONSTRAINT `goal_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goal`
--

LOCK TABLES `goal` WRITE;
/*!40000 ALTER TABLE `goal` DISABLE KEYS */;
INSERT INTO `goal` VALUES (0,0,0,'67'),(1,0,0,'79'),(2,1,1,'7'),(3,2,3,'117'),(4,3,4,'113'),(5,67,209,'86'),(6,4,6,'28'),(7,4,7,'38'),(8,4,8,'59'),(9,4,9,'65'),(10,4,5,'69'),(11,5,1,'27'),(12,5,1,'45'),(13,5,26,'90'),(14,7,11,'85'),(15,8,12,'23'),(16,8,25,'55'),(17,8,47,'74'),(18,8,15,'80'),(19,8,16,'83'),(20,9,17,'57'),(21,9,18,'69'),(22,9,19,'81'),(23,9,20,'83'),(24,10,21,'38'),(25,10,22,'82'),(26,10,21,'105'),(27,10,23,'116'),(28,11,24,'2'),(29,11,20,'25'),(30,11,13,'43'),(31,12,10,'18'),(32,12,27,'37'),(33,12,28,'66'),(34,12,29,'71'),(35,12,30,'86'),(36,21,115,'45'),(37,21,0,'50'),(38,21,92,'87'),(39,22,116,'15'),(40,22,92,'32'),(41,22,117,'45'),(42,22,0,'55'),(43,23,0,'10'),(44,23,0,'13'),(45,23,118,'38'),(46,23,119,'39'),(47,23,120,'56'),(48,23,92,'62'),(49,23,121,'64'),(50,24,92,'67'),(51,24,0,'87'),(52,25,112,'23'),(53,25,92,'45'),(54,25,117,'50'),(55,26,0,'49'),(56,27,70,'20'),(57,27,70,'25'),(58,27,122,'40'),(59,27,123,'45'),(60,27,70,'70'),(61,27,124,'73'),(62,27,125,'84'),(63,27,126,'90'),(64,28,70,'19'),(65,28,127,'90'),(66,29,128,'50'),(67,29,70,'79'),(68,30,129,'88'),(69,31,122,'39'),(70,32,122,'75'),(71,33,130,'1'),(72,33,131,'9'),(73,33,132,'13'),(74,33,132,'32'),(75,33,133,'90'),(76,34,134,'56'),(77,34,134,'78'),(78,34,135,'88'),(79,35,51,'40'),(80,35,137,'83'),(81,36,138,'22'),(82,37,2,'26'),(83,37,140,'87'),(84,38,141,'90'),(85,39,142,'6'),(86,39,143,'59'),(87,39,143,'69'),(88,40,144,'119'),(89,40,145,'120'),(90,42,165,'9'),(91,42,166,'81'),(92,43,167,'55'),(93,43,165,'61'),(94,44,52,'28'),(95,44,168,'41'),(96,44,167,'83'),(97,44,1,'90'),(98,45,165,'57'),(99,46,1,'33'),(100,13,84,'12'),(101,13,99,'18'),(102,13,169,'78'),(103,13,170,'89'),(104,13,99,'101'),(105,13,99,'120'),(106,14,171,'15'),(107,14,172,'17'),(108,14,173,'69'),(109,14,60,'78'),(110,15,174,'3'),(111,15,60,'9'),(112,15,60,'32'),(113,15,10,'55'),(114,15,175,'68'),(115,15,176,'80'),(116,15,10,'90'),(117,16,177,'6'),(118,16,178,'8'),(119,16,82,'10'),(120,16,83,'18'),(121,16,83,'84'),(122,17,179,'47'),(123,17,180,'66'),(124,17,181,'79'),(125,18,182,'6'),(126,18,183,'8'),(127,18,78,'19'),(128,18,182,'32'),(129,18,76,'70'),(130,18,78,'82'),(131,19,184,'71'),(132,19,185,'81'),(133,19,75,'95'),(134,20,186,'12'),(135,20,187,'20'),(136,20,54,'37'),(137,20,73,'57'),(138,20,188,'68'),(139,20,189,'89'),(140,47,190,'48'),(141,47,70,'79'),(142,49,191,'5'),(143,49,93,'10'),(144,49,192,'98'),(145,52,132,'97'),(146,53,193,'8'),(147,53,127,'90'),(148,54,91,'18'),(149,54,194,'88'),(150,54,195,'119'),(151,55,196,'11'),(152,55,197,'37'),(153,55,197,'107'),(154,56,0,'46'),(155,56,198,'87'),(156,58,90,'6'),(157,58,199,'10'),(158,58,112,'16'),(159,58,200,'45'),(160,59,201,'113'),(161,60,202,'78'),(162,60,203,'88'),(163,60,203,'101'),(164,60,103,'115'),(165,61,48,'6'),(166,61,204,'18'),(167,62,205,'25'),(168,62,40,'88'),(169,62,40,'100'),(170,63,11,'60'),(171,63,68,'80'),(172,64,32,'17'),(173,64,206,'67'),(174,1,2,'19');
/*!40000 ALTER TABLE `goal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `golden_ball`
--

DROP TABLE IF EXISTS `golden_ball`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `golden_ball` (
  `id_golden_ball` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  PRIMARY KEY (`id_golden_ball`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `golden_ball_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `golden_ball_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `golden_ball`
--

LOCK TABLES `golden_ball` WRITE;
/*!40000 ALTER TABLE `golden_ball` DISABLE KEYS */;
INSERT INTO `golden_ball` VALUES (0,10,21),(1,11,17),(2,12,31),(3,13,32),(4,14,33),(5,15,0),(6,16,34),(7,17,1),(8,18,35),(9,19,36),(10,20,37),(11,9,NULL),(12,8,NULL),(13,7,NULL),(14,6,NULL),(15,5,NULL),(16,4,NULL),(17,3,NULL),(18,2,NULL),(19,1,NULL),(20,0,NULL);
/*!40000 ALTER TABLE `golden_ball` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `golden_boot`
--

DROP TABLE IF EXISTS `golden_boot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `golden_boot` (
  `id_golden_boot` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `goals` smallint DEFAULT NULL,
  PRIMARY KEY (`id_golden_boot`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `golden_boot_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `golden_boot_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `golden_boot`
--

LOCK TABLES `golden_boot` WRITE;
/*!40000 ALTER TABLE `golden_boot` DISABLE KEYS */;
INSERT INTO `golden_boot` VALUES (0,0,54,4,8),(1,1,55,4,5),(2,2,56,4,7),(3,3,57,6,9),(4,4,58,5,11),(5,5,59,6,13),(6,6,60,6,4),(7,6,61,6,4),(8,6,62,6,4),(9,6,63,6,4),(10,6,64,3,4),(11,6,65,4,4),(12,7,66,6,9),(13,8,13,6,10),(14,9,67,7,7),(15,10,21,7,6),(16,11,17,7,6),(17,12,68,5,6),(18,13,32,7,6),(19,14,69,3,6),(20,14,48,7,6),(21,15,41,7,6),(22,16,0,7,8),(23,17,70,7,5),(24,18,44,6,5),(25,19,71,5,6),(26,20,72,6,6);
/*!40000 ALTER TABLE `golden_boot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `golden_glove`
--

DROP TABLE IF EXISTS `golden_glove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `golden_glove` (
  `id_golden_glove` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  PRIMARY KEY (`id_golden_glove`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `golden_glove_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `golden_glove_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `golden_glove`
--

LOCK TABLES `golden_glove` WRITE;
/*!40000 ALTER TABLE `golden_glove` DISABLE KEYS */;
INSERT INTO `golden_glove` VALUES (0,14,144),(1,15,145),(2,16,34),(3,17,146),(4,18,147),(5,19,148),(6,20,149),(7,13,NULL),(8,12,NULL),(9,11,NULL),(10,10,NULL),(11,9,NULL),(12,8,NULL),(13,7,NULL),(14,6,NULL),(15,5,NULL),(16,4,NULL),(17,3,NULL),(18,2,NULL),(19,1,NULL),(20,0,NULL);
/*!40000 ALTER TABLE `golden_glove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `own_goal`
--

DROP TABLE IF EXISTS `own_goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `own_goal` (
  `id_own_goal` int NOT NULL,
  `game_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `minuto` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_own_goal`),
  KEY `game_id` (`game_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `own_goal_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`id_game`) ON DELETE CASCADE,
  CONSTRAINT `own_goal_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `own_goal`
--

LOCK TABLES `own_goal` WRITE;
/*!40000 ALTER TABLE `own_goal` DISABLE KEYS */;
INSERT INTO `own_goal` VALUES (0,66,207,'4'),(1,34,136,'61'),(2,36,139,'27'),(3,67,208,'25'),(4,68,210,'10'),(5,69,211,'71'),(6,69,212,'29'),(7,70,213,'88'),(8,71,214,'72'),(9,72,215,'73'),(10,73,216,'77'),(11,74,217,'45+1'),(12,75,218,'74'),(13,76,219,'46'),(14,77,220,'17'),(15,4,5,'19');
/*!40000 ALTER TABLE `own_goal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `penalty`
--

DROP TABLE IF EXISTS `penalty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `penalty` (
  `id_penalty` int NOT NULL,
  `game_id` int DEFAULT NULL,
  `home_score` smallint DEFAULT NULL,
  `away_score` smallint DEFAULT NULL,
  PRIMARY KEY (`id_penalty`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `penalty_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`id_game`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penalty`
--

LOCK TABLES `penalty` WRITE;
/*!40000 ALTER TABLE `penalty` DISABLE KEYS */;
INSERT INTO `penalty` VALUES (0,1,5,3),(1,6,3,2),(2,47,4,2),(3,48,1,3),(4,50,0,3),(5,51,3,5),(6,53,3,2),(7,56,4,2),(8,57,3,4),(9,58,4,3),(10,60,4,5),(11,61,1,3),(12,63,4,3),(13,64,3,4),(14,65,2,3);
/*!40000 ALTER TABLE `penalty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player` (
  `id_player` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `position` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `participations` smallint DEFAULT NULL,
  `titles` smallint DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `wins` smallint DEFAULT NULL,
  `draws` smallint DEFAULT NULL,
  `losses` smallint DEFAULT NULL,
  `goals` smallint DEFAULT NULL,
  `yellow_cards` smallint DEFAULT NULL,
  `red_cards` smallint DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  PRIMARY KEY (`id_player`),
  KEY `team_id` (`team_id`),
  CONSTRAINT `player_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`id_team`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES (0,'Ronaldo','Forward',4,2,19,15,1,3,15,2,0,4),(1,'Zinedine Zidane','Midfielder',3,1,12,7,4,1,5,4,2,27),(2,'Marco Materazzi','Defender',2,1,5,3,1,1,2,0,1,18),(3,'Andres Iniesta','Midfielder',4,1,14,8,3,3,2,1,0,9),(4,'Mario Gotze','Midfielder',1,1,6,5,1,0,2,0,0,8),(5,'Mario Mandzukic','Forward',2,0,8,4,2,2,5,2,0,35),(6,'Ivan Perisic','Forward',2,0,10,5,2,3,5,0,0,35),(7,'Antoine Griezmann','Forward',2,1,12,9,2,1,4,0,0,27),(8,'Paul Pogba','Midfielder',2,1,11,9,1,1,2,2,0,27),(9,'Kylian Mbappe','Forward',1,1,7,6,1,0,4,2,0,27),(10,'Pele','Forward',4,3,14,12,1,1,12,0,0,4),(11,'Andreas Brehme','Defender/Midfielder',3,1,16,9,4,3,4,4,0,8),(12,'Jose Luis Brown','Defender',1,1,7,6,1,0,1,1,0,14),(13,'Gerd Muller','Forward',2,1,13,11,0,2,14,2,0,8),(14,'Jorg Bohme','Midfielder',1,0,0,0,0,0,0,0,0,8),(15,'Rudi Voller','Forward',3,1,15,8,4,3,8,3,1,8),(16,'Jorge Burruchaga','Midfielder',2,1,14,8,4,2,3,1,0,14),(17,'Paolo Rossi','Forward',3,1,14,8,4,2,9,1,0,18),(18,'Marco Tardelli','Midfielder',3,1,13,8,4,1,2,3,0,18),(19,'Alessandro Altobelli','Forward',2,1,7,4,2,1,5,0,0,18),(20,'Paul Breitner','Midfielder',2,1,14,9,2,3,4,0,0,8),(21,'Mario Kempes','Forward',3,1,18,8,3,7,6,1,0,14),(22,'Dick Nanninga','Forward',1,0,3,0,2,1,1,0,1,20),(23,'Daniel Bertoni','Forward',2,1,11,6,1,4,4,1,0,14),(24,'Johan Neeskens','Midfielder',2,0,12,7,2,3,5,2,0,20),(25,'Jorge Valdano','Forward',2,1,9,7,1,1,4,1,0,14),(26,'Emmanuel Petit','Midfielder',2,1,7,5,1,1,2,3,0,27),(27,'Roberto Boninsegna','Forward',2,0,7,3,2,2,2,1,0,18),(28,'Gerson','Midfielder',2,1,5,4,0,1,1,0,0,4),(29,'Jairzinho','Forward',3,1,16,10,2,4,9,2,0,4),(30,'Carlos Alberto','Defender',1,1,6,6,0,0,1,0,0,4),(31,'Maradona','Midfielder',4,1,21,12,4,5,8,4,1,14),(32,'Salvatore Schillaci','Forward',1,0,7,6,1,0,6,0,0,18),(33,'Romario','Forward',2,1,8,6,2,0,5,0,0,4),(34,'Oliver Kahn','Goalkeeper',4,0,8,6,1,1,0,1,0,8),(35,'Diego Forlan','Midfielder',3,0,10,3,3,4,6,1,0,39),(36,'Lionel Messi','Forward',4,0,19,12,3,4,6,1,0,14),(37,'Luka Modric','Midfielder',3,0,12,5,4,3,2,0,0,35),(38,'Falcao','Midfielder',2,0,7,6,0,1,3,1,0,4),(39,'Lothar Matthaus','Midfielder',5,1,25,15,6,4,6,5,0,8),(40,'Roberto Baggio','Forward',3,0,16,10,5,1,9,1,0,18),(41,'Davor Suker','Forward',3,0,8,5,0,3,6,1,0,35),(42,'Fabio Cannavaro','Defender',4,1,18,9,7,2,0,4,0,18),(43,'Wesley Sneijder','Midfielder',3,0,17,12,3,2,6,2,0,20),(44,'Thomas Muller','Forward/Midfielder',3,1,16,12,1,3,10,3,0,8),(45,'Eden Hazard','Forward/Midfielder',2,0,11,9,0,2,3,2,0,22),(46,'Dirceu','Midfielder/Forward',3,0,12,7,3,2,3,1,0,4),(47,'Karl-Heinz Rummenigge','Forward',3,0,19,7,7,5,9,0,0,8),(48,'Hristo Stoichkov','Forward',2,0,10,3,2,5,6,3,0,13),(49,'Lilian Thuram','Defender',3,1,16,9,5,2,2,0,0,27),(50,'Hong Myung-Bo','Defender',4,0,16,3,5,8,2,1,0,10),(51,'Andrea Pirlo','Midfielder',3,1,11,6,2,3,1,0,0,18),(52,'David Villa','Forward',3,1,12,10,0,2,9,0,0,9),(53,'Arjen Robben','Forward',3,0,15,11,2,2,6,4,0,20),(54,'Guillermo Stabile','Forward',1,0,4,3,0,1,8,0,0,14),(55,'Oldrich Nejedly','Forward',2,0,6,4,1,1,7,0,0,52),(56,'Leonidas da Silva','Forward',2,0,5,3,1,1,8,0,0,4),(57,'Ademir de Menezes','Forward',1,0,6,4,1,1,9,0,0,4),(58,'Sandor Kocsis','Forward',1,0,5,4,0,1,11,0,0,57),(59,'Just Fontaine','Forward',1,0,6,4,0,2,13,0,0,27),(60,'Vava','Forward',2,2,10,8,2,0,9,0,0,4),(61,'Garrincha','Forward',3,2,12,10,1,1,5,0,1,4),(62,'Leonel Sanchez','Forward',2,0,9,4,1,4,4,0,0,25),(63,'Drazen Jerkovic','Forward',2,0,6,3,0,3,4,0,0,31),(64,'Florian Albert','Forward',2,0,7,4,0,3,4,0,0,57),(65,'Valentin Ivanov','Midfielder/Forward',2,0,9,4,2,3,5,0,0,6),(66,'Eusebio','Forward',1,0,6,5,0,1,9,0,0,44),(67,'Grzegorz Lato','Forward',3,0,20,12,4,4,10,0,0,45),(68,'Gary Lineker','Forward',2,0,12,5,4,3,10,0,0,33),(69,'Oleg Salenko','Forward',1,0,3,1,0,2,6,0,0,6),(70,'Miroslav Klose','Forward',4,1,24,17,3,4,16,3,0,8),(71,'James Rodriguez','Midfielder',2,0,8,6,0,2,6,2,0,3),(72,'Harry Kane','Forward',1,0,6,3,1,2,6,0,0,33),(73,'Pedro Cea','Forward',1,1,4,4,0,0,5,0,0,39),(74,'Edmund Conen','Forward',1,0,4,3,0,1,4,0,0,8),(75,'Angelo Schiavio','Forward',1,1,4,3,1,0,4,0,0,18),(76,'Gyorgy Sarosi','Forward/Midfielder',2,0,5,3,0,2,6,0,0,57),(77,'Gyula Zsengeller','Forward',1,0,4,3,0,1,5,0,0,57),(78,'Silvio Piola','Forward',1,1,4,4,0,0,5,0,0,18),(79,'Oscar Miguez','Forward',2,1,7,6,1,0,8,0,0,39),(80,'Erich Probst','Forward',1,0,5,4,0,1,6,0,0,26),(81,'Sepp Huegi','Forward',1,0,3,2,0,1,6,0,0,1),(82,'Max Morlock','Midfielder/Forward',1,1,5,5,0,0,6,0,0,8),(83,'Helmut Rahn','Forward',2,1,10,5,2,3,10,0,0,8),(84,'Helmut Haller','Forward/Midfielder',3,0,9,5,2,2,6,0,0,8),(85,'Andrzej Szarmach','Forward',3,0,13,9,2,2,7,1,0,45),(86,'Teofilo Cubillas','Midfielder/Forward',3,0,13,4,3,6,10,0,0,56),(87,'Careca','Forward',2,0,9,7,1,1,7,1,0,4),(88,'Emilio Butragueno','Forward',2,0,9,5,2,2,5,0,0,9),(89,'Tomas Skuhravy','Forward',1,0,5,3,0,2,5,1,0,52),(90,'Gabriel Omar Batistuta','Forward',3,0,12,6,2,4,10,2,0,14),(91,'Christian Vieri','Forward',2,0,9,4,3,2,9,1,0,18),(92,'Rivaldo','Midfielder/Forward',2,1,14,11,1,2,8,0,0,4),(93,'Hernan Crespo','Forward',3,0,8,4,3,1,4,1,0,14),(94,'Bert Patenaude','Forward',1,0,3,2,0,1,3,0,0,2),(95,'Estanislao Basora','Forward',1,0,6,3,1,2,4,0,0,9),(96,'Valeriy Porkuyan','Forward',2,0,3,2,0,1,4,0,0,6),(97,'Franz Beckenbauer','Defender',3,1,18,14,1,3,5,2,0,8),(98,'Ferenc Bene','Forward',1,0,4,2,0,2,4,0,0,57),(99,'Geoff Hurst','Forward',2,1,6,4,0,2,5,0,0,33),(100,'Rob Rensenbrink','Forward',2,0,13,8,2,3,6,0,0,20),(101,'Zico','Midfielder',3,0,14,9,4,1,5,1,0,4),(102,'Roger Milla','Forward',3,0,10,3,3,4,5,3,0,7),(103,'Kennet Andersson','Forward',1,0,7,3,3,1,5,2,0,5),(104,'Neymar','Forward/Midfielder',2,0,10,6,3,1,6,2,0,4),(105,'Romelu Lukaku','Forward',2,0,10,8,0,2,5,0,0,22),(106,'Wladyslaw Zmuda','Defender',4,0,21,12,4,5,0,1,0,45),(107,'Antonio Cabrini','Defender/Midfielder',3,1,18,9,6,3,1,2,0,18),(108,'Manuel Amoros','Defender',2,0,12,6,4,2,1,3,0,27),(109,'Enzo Scifo','Midfielder',4,0,17,6,4,7,3,1,0,22),(110,'Robert Prosinecki','Midfielder',3,0,9,4,1,4,3,1,0,35),(111,'Marc Overmars','Forward',2,0,11,6,2,3,1,0,0,20),(112,'Michael Owen','Forward',3,0,12,6,4,2,4,0,0,33),(113,'Landon Donovan','Forward',3,0,12,3,4,5,5,0,0,2),(114,'Lukas Podolski','Forward',3,1,15,11,1,3,5,1,0,8),(115,'Hasan Sas','Forward',1,0,6,3,1,2,2,2,0,37),(116,'Roberto Carlos','Defender',3,1,17,13,1,3,1,2,0,4),(117,'Ronaldinho Gaucho','Midfielder',2,1,10,9,0,1,2,1,1,4),(118,'Edmilson','Defender',1,1,6,6,0,0,1,0,0,4),(119,'Paulo Wanchope','Forward',2,0,6,1,1,4,3,0,0,42),(120,'Ronald Gomez','Forward',2,0,6,1,1,4,3,2,0,42),(121,'Junior','Defender/Midfielder',1,1,1,1,0,0,1,0,0,4),(122,'Michael Ballack','Midfielder',2,0,11,8,2,1,3,4,0,8),(123,'Carsten Jancker','Forward',1,0,3,2,1,0,1,1,0,8),(124,'Thomas Linke','Defender',1,0,7,5,1,1,1,0,0,8),(125,'Oliver Bierhoff','Forward',2,0,10,6,2,2,4,0,0,8),(126,'Bernd Schneider','Midfielder',2,0,14,10,2,2,1,1,0,8),(127,'Robbie Keane','Forward',1,0,4,1,3,0,3,0,0,17),(128,'Marco Bode','Forward/Midfielder',1,0,6,4,1,1,1,0,0,8),(129,'Oliver Neuville','Forward',2,0,13,10,1,2,2,1,0,8),(130,'Hakan Sukur','Forward',1,0,7,4,1,2,1,1,0,41),(131,'Lee Eul-Yong','Midfielder',2,0,6,2,3,1,1,1,0,10),(132,'Ilhan Mansiz','Forward',1,0,7,4,1,2,3,1,0,41),(133,'Song Chong-Gug','Defender/Midfielder',2,0,8,4,2,2,1,1,0,10),(134,'Bastian Schweinsteiger','Midfielder',3,1,20,15,2,3,2,4,0,8),(135,'Nuno Gomes','Forward',2,0,4,1,0,3,1,1,0,44),(136,'Petit','Midfielder',2,0,9,5,1,3,0,3,0,44),(137,'Vicenzo Iaquinta','Forward',2,1,8,3,4,1,2,1,0,18),(138,'Alberto Gilardino','Forward',2,1,7,4,3,0,1,0,0,18),(139,'Cristian Zaccardo','Defender',1,1,3,2,1,0,0,0,0,18),(140,'Filippo Inzaghi','Forward',3,1,5,2,2,1,1,0,0,18),(141,'Francesco Totti','Forward/Midfielder',2,1,11,6,3,2,1,4,0,18),(142,'Gianluca Zambrotta','Defender/Midfielder',3,1,13,5,5,3,1,4,0,18),(143,'Luca Toni','Forward',1,1,6,4,2,0,2,0,0,18),(144,'Michel Preudhomme','Goalkeeper',2,0,8,4,0,4,0,0,0,22),(145,'Fabien Barthez','Goalkeeper',3,1,17,10,5,2,0,0,0,27),(146,'Gianluigi Buffon','Goalkeeper',5,1,14,6,4,4,0,0,0,18),(147,'Iker Casillas','Goalkeeper',4,1,17,11,2,4,0,1,0,9),(148,'Manuel Neuer','Goalkeeper',3,1,16,11,1,4,0,0,0,8),(149,'Thibaut Courtouis','Goalkeeper',2,0,12,10,0,2,0,0,0,22),(150,'Marcos','Goalkeeper',1,1,7,7,0,0,0,0,0,4),(151,'Lucio','Defender',3,1,17,14,1,2,0,1,0,4),(152,'Roque Junior','Defender',1,1,6,6,0,0,0,2,0,4),(153,'Cafu','Defender/Midfielder',4,2,20,16,1,3,0,6,0,4),(154,'Gilberto Silva','Midfielder/Defender',3,1,16,13,1,2,0,1,0,4),(155,'Kleberson','Midfielder',2,1,6,6,0,0,0,0,0,4),(156,'Juninho Paulista','Midfielder',1,1,5,5,0,0,0,0,0,4),(157,'Denilson','Forward',2,1,12,9,1,2,0,1,0,4),(158,'Christoph Metzelder','Defender',2,0,13,9,2,2,0,2,0,8),(159,'Carsten Ramelow','Midfielder/Defender',1,0,5,3,1,1,0,2,0,8),(160,'Torsten Frings','Midfielder',2,0,13,10,2,1,1,3,0,8),(161,'Dietmar Hamann','Midfielder',2,0,11,7,2,2,0,4,0,8),(162,'Jens Jeremies','Midfielder/Defender',2,0,10,6,2,2,0,2,0,8),(163,'Gerald Asamoah','Forward',2,0,4,3,0,1,0,0,0,8),(164,'Christian Ziege','Midfielder/Defender',2,0,9,6,2,1,0,2,0,8),(165,'Thierry Henry','Forward',4,1,17,9,6,2,6,0,1,27),(166,'Park Ji-Sung','Midfielder',3,0,14,5,4,5,3,1,0,10),(167,'Patrick Vieira','Midfielder',3,1,12,6,4,2,2,2,0,27),(168,'Franck Ribery','Forward/Midfielder',2,0,10,4,4,2,1,2,0,27),(169,'Martin Peters','Midfielder',2,1,9,7,0,2,2,1,0,33),(170,'Wolfgang Weber','Defender',2,0,8,6,1,1,1,0,0,8),(171,'Josef Masopust','Midfielder',2,0,10,4,2,4,1,0,0,52),(172,'Amarildo','Forward',1,1,4,4,0,0,3,0,0,4),(173,'Zito','Midfielder',3,2,10,9,1,0,1,0,0,4),(174,'Nils Liedholm','Midfielder',1,0,6,4,1,1,2,0,0,5),(175,'Zagallo','Forward',2,2,12,10,2,0,2,0,0,4),(176,'Agne Simonsson','Forward',1,0,5,4,0,1,4,0,0,5),(177,'Ferenc Puskas','Forward',2,0,6,3,0,3,4,0,0,57),(178,'Zoltan Czibor','Forward',1,0,5,4,0,1,3,0,0,57),(179,'Friaca','Forward',1,0,4,2,1,1,1,0,0,4),(180,'Juan Schiaffino','Midfielder/Forward',2,1,9,6,1,2,5,0,0,39),(181,'Alcides Ghiggia','Forward',1,1,4,3,1,0,4,0,0,39),(182,'Gino Colaussi','Forward',1,1,3,3,0,0,4,0,0,18),(183,'Pal Titkos','Forward',1,0,2,1,0,1,1,0,0,57),(184,'Antonin Puc','Forward',2,0,6,4,1,1,2,0,0,52),(185,'Raimundo Orsi','Forward',1,1,5,4,1,0,3,0,0,18),(186,'Pablo Dorado','Forward',1,1,3,3,0,0,2,0,0,39),(187,'Carlos Peucelle','Midfielder',1,0,4,3,0,1,3,0,0,14),(188,'Santos Iriarte','Forward',1,1,4,4,0,0,2,0,0,39),(189,'Hector Castro','Forward',1,1,2,2,0,0,2,0,0,39),(190,'Roberto Ayala','Defender',3,0,10,6,3,1,1,1,0,14),(191,'Rafa Marquez','Defender/Midfielder',5,0,19,8,4,7,3,5,1,16),(192,'Maxi Rodriguez','Forward/Midfielder',3,0,12,8,3,1,3,1,0,14),(193,'Fernando Morientes','Forward',2,0,7,4,3,0,5,1,0,9),(194,'Seol Ki-Hyeon','Forward',2,0,9,3,3,3,1,1,0,10),(195,'Ahn Jung-Hwan','Forward',3,0,10,4,3,3,3,1,0,10),(196,'Henrik Larsson','Forward',3,0,13,4,7,2,5,2,0,5),(197,'Henri Camara','Forward',1,0,4,1,2,1,2,1,0,38),(198,'Patrick Kluivert','Forward',1,0,4,1,2,1,2,0,1,20),(199,'Alan Shearer','Forward',1,0,4,2,1,1,2,1,0,33),(200,'Javier Zanetti','Defender',2,0,8,4,2,2,1,0,0,14),(201,'Laurent Blanc','Defender',1,1,5,4,1,0,1,1,1,27),(202,'Tomas Brolin','Midfielder/ Forward',2,0,10,3,3,4,4,1,0,5),(203,'Florin Raducioiu','Forward',2,0,7,3,2,2,4,2,0,0),(204,'Alberto Garcia Aspe','Midfielder',3,0,8,2,4,2,2,4,0,16),(205,'Emmanuel Amunike','Forward',1,0,4,2,0,2,2,1,0,12),(206,'Claudio Paul Caniggia','Forward',3,0,9,4,3,2,4,3,1,14),(207,'Carlos Gamarra','Defender',3,0,11,3,3,5,0,0,0,30),(208,'Brent Sancho','Defender',1,0,3,0,1,2,0,1,0,47),(209,'Nelson Cuevas','Forward',2,0,4,2,0,2,3,0,0,30),(210,'Carles Puyol','Defender',3,1,14,10,2,2,1,3,0,9),(211,'Jeff Agoos','Defender',2,0,3,1,1,1,0,1,0,2),(212,'Jorge Costa','Defender',1,0,3,1,0,2,0,2,0,44),(213,'Georgi Bachev','Midfielder/Forward',1,0,2,0,0,2,0,1,0,13),(214,'Sinisa Mihaijlovic','Defender',1,0,4,2,1,1,1,0,0,31),(215,'Andoni Zubizarreta','Goalkeeper',4,0,16,8,4,4,0,0,0,9),(216,'Pierre Issa','Defender',2,0,4,0,3,1,0,2,0,29),(217,'Youssef Chippo','Midfielder',1,0,3,1,1,1,0,1,0,23),(218,'Tom Boyd','Defender',1,0,3,0,1,2,0,0,0,24),(219,'Daniel Agger','Defender',1,0,3,1,0,2,0,0,0,28),(220,'Park Chu-Young','Forward',3,0,7,1,2,4,1,1,0,10),(221,'Dida','Goalkeeper',3,1,5,4,0,1,0,0,0,4),(222,'Rogerio Ceni','Goalkeeper',2,1,1,1,0,0,0,0,0,4),(223,'Belletti','Defender',1,1,1,1,0,0,0,0,0,4),(224,'Anderson Polga','Defender',1,1,2,2,0,0,0,0,0,4),(225,'Ricardinho','Midfielder',2,1,5,5,0,0,0,0,0,4),(226,'Vampeta','Midfielder',1,1,1,1,0,0,0,0,0,4),(227,'Kaka','Midfielder',3,1,10,8,0,2,1,3,0,4),(228,'Edilson','Forward',1,1,4,4,0,0,0,0,0,4),(229,'Luizao','Forward',1,1,2,2,0,0,0,0,0,4),(230,'Jens Lehmann','Goalkeeper',3,0,6,4,1,1,0,0,0,8),(231,'Hans-Jorg Butt','Goalkeeper',2,0,1,1,0,0,0,0,0,8),(232,'Marko Rehmer','Defender',1,0,1,1,0,0,0,0,0,8),(233,'Frank Baumann','Defender/Midfielder',1,0,1,1,0,0,0,1,0,8),(234,'Sebastian Kehl','Midfielder',2,0,6,5,0,1,0,1,0,8),(235,'Lars Ricken','Midfielder',1,0,0,0,0,0,0,0,0,8);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referee`
--

DROP TABLE IF EXISTS `referee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referee` (
  `id_referee` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nationality` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_referee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referee`
--

LOCK TABLES `referee` WRITE;
/*!40000 ALTER TABLE `referee` DISABLE KEYS */;
INSERT INTO `referee` VALUES (0,'Pierluigi Collina','Italy'),(1,'Horacio Elizondo','Argentina'),(2,'Howard Webb','England'),(3,'Nicola Rizzoli','Italy'),(4,'Nestor Pitana','Argentina'),(5,'Said Belqola','Morocco'),(6,'Sandor Puhl','Hungary'),(7,'Edgardo Codesal','Mexico'),(8,'Romualdo Arppi Filho','Brazil'),(9,'Arnaldo CÃ©sar Coelho','Brazil'),(10,'Sergio Gonella','Italy'),(11,'Jack Taylor','England'),(12,'Rudi Glockner','East Germany'),(13,'Gottfried Dienst','Switzerland'),(14,'Nikolay Latyshev','URSS'),(15,'Maurice Guigue','France'),(16,'William Ling','England'),(17,'George Reader','England'),(18,'Georges Capdeville','France'),(19,'Ivan Eklind','Sweden'),(20,'John Langenus','Belgium'),(21,'Kim Young-Joo','South Korea'),(22,'Anders Frisk','Sweden'),(23,'Gamal Al-Ghandour','Egypt'),(24,'Peter Prendergast','Jamaica'),(25,'Felipe Ramos','Mexico'),(26,'Kim Milton Nielsen','Denmark'),(27,'Ubaldo Aquino','Paraguay'),(28,'Lopez Nieto','Spain'),(29,'Carlos Batres','Guatemala'),(30,'Hugh Dallas','Scotland'),(31,'Urs Meier','Switzerland'),(32,'Saad Al-Fadhli','Kuwait'),(33,'Toru Kamikawa','Japan'),(34,'Carlos Simon','Brazil'),(35,'Jorge Larrionda','Uruguay'),(36,'Benito Archundia','Mexico'),(37,'Medina Cantalejo','Spain'),(38,'Frank de Bleeckere','Belgium'),(39,'Valentin Ivanov','Russia'),(40,'Roberto Rosetti','Italy'),(41,'Lubos Michel','Slovakia'),(42,'Massimo Busacca','Switzerland'),(43,'Oscar Ruiz','Colombia'),(44,'Byron Moreno','Ecuador'),(45,'Ali Bujsaim','United Arab Emirates'),(46,'Philip Don','England'),(47,'Jamal Al Sharif','Syria'),(48,'Arturo Brizio Carter','Mexico'),(49,'Jose Antonio Wright','Brazil'),(50,'Michel Vautrot','France'),(51,'Kurt Rothlisberger','Switzerland'),(52,'Marco Rodriguez','Mexico'),(53,'Mario van der Ende','Netherlands'),(54,'Esfandiar Baharmast','United States of America'),(55,'Marcio Rezende de Freitas','Brazil'),(56,'Pirom Un-prasert','Thailand'),(57,'Jose Maria Garcia-Aranda','Spain'),(58,'Stephane Lannoy','France');
/*!40000 ALTER TABLE `referee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `silver_ball`
--

DROP TABLE IF EXISTS `silver_ball`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `silver_ball` (
  `id_silver_ball` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  PRIMARY KEY (`id_silver_ball`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `silver_ball_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `silver_ball_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `silver_ball`
--

LOCK TABLES `silver_ball` WRITE;
/*!40000 ALTER TABLE `silver_ball` DISABLE KEYS */;
INSERT INTO `silver_ball` VALUES (0,10,17),(1,11,38),(2,12,NULL),(3,13,39),(4,14,40),(5,15,41),(6,16,0),(7,17,42),(8,18,43),(9,19,44),(10,20,45),(11,9,NULL),(12,8,NULL),(13,7,NULL),(14,6,NULL),(15,5,NULL),(16,4,NULL),(17,3,NULL),(18,2,NULL),(19,1,NULL),(20,0,NULL);
/*!40000 ALTER TABLE `silver_ball` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `silver_shoe`
--

DROP TABLE IF EXISTS `silver_shoe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `silver_shoe` (
  `id_Silver_Shoe` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `goals` smallint DEFAULT NULL,
  PRIMARY KEY (`id_Silver_Shoe`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `silver_shoe_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `silver_shoe_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `silver_shoe`
--

LOCK TABLES `silver_shoe` WRITE;
/*!40000 ALTER TABLE `silver_shoe` DISABLE KEYS */;
INSERT INTO `silver_shoe` VALUES (0,0,73,4,5),(1,1,74,4,4),(2,1,75,4,4),(3,2,76,4,5),(4,2,77,4,5),(5,2,78,4,5),(6,3,79,4,5),(7,4,80,5,6),(8,4,81,3,6),(9,4,82,5,6),(10,5,83,4,6),(11,5,10,4,6),(12,6,NULL,NULL,NULL),(13,7,84,5,6),(14,8,27,6,7),(15,9,24,7,5),(16,9,85,6,5),(17,10,86,6,5),(18,11,47,7,5),(19,12,87,5,5),(20,12,88,5,5),(21,12,31,7,5),(22,13,89,5,5),(23,14,NULL,NULL,NULL),(24,15,90,5,5),(25,15,91,5,5),(26,16,92,7,5),(27,16,70,7,5),(28,17,93,4,3),(29,18,52,7,5),(30,19,44,7,5),(31,20,7,7,4);
/*!40000 ALTER TABLE `silver_shoe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stadium`
--

DROP TABLE IF EXISTS `stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stadium` (
  `id_stadium` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `capacity` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  PRIMARY KEY (`id_stadium`),
  KEY `city_id` (`city_id`),
  CONSTRAINT `stadium_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `city` (`id_city`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stadium`
--

LOCK TABLES `stadium` WRITE;
/*!40000 ALTER TABLE `stadium` DISABLE KEYS */;
INSERT INTO `stadium` VALUES (0,'Olympiastadion',72000,0),(1,'Allianz Arena',66000,1),(2,'Signal Iduna Park',65000,2),(3,'Gottlieb-Daimler-Stadion',52000,3),(4,'Arena AufSchalke',52000,4),(5,'AOL Arena',50000,5),(6,'Commerzbank-Arena',48000,6),(7,'Fritz-Walter-Stadion',46000,7),(8,'RheinEnergieStadion',45000,8),(9,'AWD-Arena',43000,9),(10,'Zentralstadion',43000,10),(11,'easyCredit-Stadion',41000,11),(12,'Deagu World Cup Stadium',68014,12),(13,'Seoul World Cup Stadium',63961,13),(14,'Busan Asiad Stadium',55982,14),(15,'Incheon World Cup Stadium',52179,15),(16,'Ulsan Munsu Football Stadium',43550,16),(17,'Suwon World Cup Stadium',43188,17),(18,'Gwangju World Cup Stadium',42880,18),(19,'Jeonju World Cup Stadium',42391,19),(20,'Jeju World Cup Stadium',42256,20),(21,'Daejeon World Cup Stadium',40407,21),(22,'International Stadium Yokohama',72327,22),(23,'Saitama Stadium',63000,23),(24,'Shizuoka Stadium ECOPA',50600,24),(25,'Nagai Stadium',50000,25),(26,'Miyagi Stadium',49000,26),(27,'Oita Stadium',43000,27),(28,'Niigata Stadium',42300,28),(29,'Kashima Stadium',42000,29),(30,'Kobe Wing Stadium',42000,30),(31,'Sapporo Dome',42000,31),(32,'Stade de France',80000,32),(33,'Stade Velodrome',60000,33),(34,'Parc des Princes',48875,34),(35,'Stade de Gerland',44000,35),(36,'Stade Felix-Bollaert',41300,36),(37,'Stade de la Beaujoire',39500,37),(38,'Stadium de Toulouse',37000,38),(39,'Stade Geoffroy-Guichard',36000,39),(40,'Parc Lescure',35200,40),(41,'Stade de la Mosson',34000,41),(42,'Rose Bowl',94194,42),(43,'Stanford Stadium',84147,43),(44,'Pontiac Silverdome',77557,44),(45,'Giants Stadium',76322,45),(46,'Cotton Bowl',64000,46),(47,'Soldier Field',63160,47),(48,'Citrus Bowl',62387,48),(49,'Foxboro Stadium',54456,49),(50,'Robert F. Kennedy Memorial Stadium',53121,50),(51,'Soccer City',84490,51),(52,'Maracana',74738,52),(53,'Luzhniki Stadium',78011,53),(54,'Stadio Olimpico',73603,54),(55,'Estadio Azteca',114600,55),(56,'Santiago Bernabeu',90089,56),(57,'Estadio Monumental',74624,57),(58,'Olympiastadion',77573,1),(59,'Wembley Stadium',98600,58),(60,'Estadio Nacional',66660,59),(61,'Rasunda Stadium',52400,60),(62,'Wankdorf Stadium',64600,61),(63,'Stade Olympique de Colombes',60000,62),(64,'Stadio Nazionale PNF',47300,54),(65,'Estadio Centenario',90000,63),(66,'Stadio delle Alpi',69041,64),(67,'Stadio San Paolo',60240,65),(68,'Stadio Comunale di Firenze',47282,66);
/*!40000 ALTER TABLE `stadium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id_team` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `confederation` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `participations` smallint DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `wins` smallint DEFAULT NULL,
  `draws` smallint DEFAULT NULL,
  `losses` smallint DEFAULT NULL,
  `goals_scored` smallint DEFAULT NULL,
  `goals_against` smallint DEFAULT NULL,
  PRIMARY KEY (`id_team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (0,'Romania','UEFA',7,21,8,5,8,30,32),(1,'Switzerland','UEFA',12,37,12,8,17,50,64),(2,'USA','CONCACAF',11,33,8,6,19,37,62),(3,'Colombia','CONMEBOL',6,22,9,3,10,32,30),(4,'Brazil','CONMEBOL',22,109,73,18,18,229,105),(5,'Sweden','UEFA',12,51,19,13,19,80,73),(6,'Russia','UEFA',11,45,19,10,16,77,54),(7,'Cameroon','CAF',8,23,4,7,12,18,43),(8,'Germany','UEFA',20,109,67,20,22,226,125),(9,'Spain','UEFA',16,63,30,15,18,99,72),(10,'South Korea','AFC',11,34,6,9,19,34,70),(11,'Bolivia','CONMEBOL',3,6,0,1,5,1,20),(12,'Nigeria','CAF',6,21,6,3,12,23,30),(13,'Bulgaria','UEFA',7,26,3,8,15,22,53),(14,'Argentina','CONMEBOL',18,81,43,15,23,137,93),(15,'Greece','UEFA',3,10,2,2,6,5,20),(16,'Mexico','CONCACAF',17,57,16,14,27,60,98),(17,'Ireland','UEFA',3,13,2,8,3,10,10),(18,'Italy','UEFA',18,83,45,21,17,128,77),(19,'Norway','UEFA',3,8,2,3,3,7,8),(20,'Netherlands','UEFA',11,50,27,12,11,86,48),(21,'Saudi Arabia','AFC',6,16,3,2,11,11,39),(22,'Belgium','UEFA',14,48,20,9,19,68,72),(23,'Morocco','CAF',6,16,2,5,9,14,22),(24,'Scotland','UEFA',8,23,4,7,12,25,41),(25,'Chile','CONMEBOL',9,33,11,7,15,40,49),(26,'Austria','UEFA',7,29,12,4,13,43,47),(27,'France','UEFA',16,66,34,13,19,120,77),(28,'Denmark','UEFA',6,20,9,5,6,30,26),(29,'South Africa','CAF',3,9,2,4,3,11,16),(30,'Paraguay','CONMEBOL',8,27,7,10,10,30,38),(31,'Serbia','UEFA',13,46,18,8,20,66,63),(32,'Iran','AFC',6,15,2,4,9,9,24),(33,'England','UEFA',16,69,29,21,19,91,64),(34,'Tunisia','CAF',6,15,2,4,9,13,25),(35,'Croatia','UEFA',6,23,11,4,8,35,26),(36,'Jamaica','CONCACAF',1,3,1,0,2,3,9),(37,'Japan','AFC',7,21,5,5,11,20,29),(38,'Senegal','CAF',3,8,3,3,2,11,10),(39,'Uruguay','CONMEBOL',14,56,24,12,20,87,74),(40,'Slovenia','UEFA',2,6,1,1,4,5,10),(41,'Turkey','UEFA',2,10,5,1,4,20,17),(42,'Costa Rica','CONCACAF',6,18,5,5,8,19,28),(43,'China','AFC',1,3,0,0,3,0,9),(44,'Portugal','UEFA',8,30,14,6,10,49,35),(45,'Poland','UEFA',9,34,16,5,13,46,45),(46,'Ecuador','CONMEBOL',4,10,4,1,5,10,11),(47,'Trinidad and Tobago','CONCACAF',1,3,0,1,2,0,4),(48,'Ivory Coast','CAF',3,9,3,1,5,13,14),(50,'Angola','CAF',1,3,0,2,1,1,2),(51,'Ghana','CAF',4,12,4,3,5,13,16),(52,'Czech Republic','UEFA',9,33,12,5,16,47,49),(53,'Australia','AFC',6,16,2,4,10,13,31),(54,'Togo','CAF',1,3,0,0,3,1,6),(55,'Ukraine','UEFA',1,5,2,1,2,5,7),(56,'Peru','CONMEBOL',5,18,5,3,10,21,33),(57,'Hungary','UEFA',9,32,15,3,14,87,57);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_table_best_young_player`
--

DROP TABLE IF EXISTS `view_table_best_young_player`;
/*!50001 DROP VIEW IF EXISTS `view_table_best_young_player`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_best_young_player` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Winner`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_extra_time`
--

DROP TABLE IF EXISTS `view_table_extra_time`;
/*!50001 DROP VIEW IF EXISTS `view_table_extra_time`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_extra_time` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Score at Regular Time`,
 1 AS `Score at Extra Time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_game`
--

DROP TABLE IF EXISTS `view_table_game`;
/*!50001 DROP VIEW IF EXISTS `view_table_game`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_game` AS SELECT 
 1 AS `ID`,
 1 AS `Team`,
 1 AS `Confederation`,
 1 AS `Participations`,
 1 AS `Titles`,
 1 AS `2nd Places`,
 1 AS `3rd Places`,
 1 AS `4th Places`,
 1 AS `Games`,
 1 AS `Wins`,
 1 AS `Draws`,
 1 AS `Losses`,
 1 AS `Goals Scored`,
 1 AS `Goals Against`,
 1 AS `Saldo de Gols`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_goal`
--

DROP TABLE IF EXISTS `view_table_goal`;
/*!50001 DROP VIEW IF EXISTS `view_table_goal`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_goal` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Game`,
 1 AS `Goalscorer`,
 1 AS `Minuto`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_golden_glove`
--

DROP TABLE IF EXISTS `view_table_golden_glove`;
/*!50001 DROP VIEW IF EXISTS `view_table_golden_glove`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_golden_glove` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Winner`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_own_goal`
--

DROP TABLE IF EXISTS `view_table_own_goal`;
/*!50001 DROP VIEW IF EXISTS `view_table_own_goal`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_own_goal` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Game`,
 1 AS `Goalscorer`,
 1 AS `Minuto`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_penalty`
--

DROP TABLE IF EXISTS `view_table_penalty`;
/*!50001 DROP VIEW IF EXISTS `view_table_penalty`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_penalty` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Score at Regular Time`,
 1 AS `Score at Extra Time`,
 1 AS `Penalties`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_stadium`
--

DROP TABLE IF EXISTS `view_table_stadium`;
/*!50001 DROP VIEW IF EXISTS `view_table_stadium`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_stadium` AS SELECT 
 1 AS `ID`,
 1 AS `Name`,
 1 AS `Capacity`,
 1 AS `City`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `world_cup`
--

DROP TABLE IF EXISTS `world_cup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `world_cup` (
  `id_world_cup` int NOT NULL,
  `year` smallint DEFAULT NULL,
  `host_id` int DEFAULT NULL,
  `edition` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `number_participants` smallint DEFAULT NULL,
  `champion` int DEFAULT NULL,
  `runner_up` int DEFAULT NULL,
  `third_place` int DEFAULT NULL,
  `fourth_place` int DEFAULT NULL,
  PRIMARY KEY (`id_world_cup`),
  KEY `host_id` (`host_id`),
  KEY `champion` (`champion`),
  KEY `runner_up` (`runner_up`),
  KEY `third_place` (`third_place`),
  KEY `fourth_place` (`fourth_place`),
  CONSTRAINT `world_cup_ibfk_1` FOREIGN KEY (`host_id`) REFERENCES `country` (`id_host`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_2` FOREIGN KEY (`champion`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_3` FOREIGN KEY (`runner_up`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_4` FOREIGN KEY (`third_place`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_5` FOREIGN KEY (`fourth_place`) REFERENCES `team` (`id_team`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world_cup`
--

LOCK TABLES `world_cup` WRITE;
/*!40000 ALTER TABLE `world_cup` DISABLE KEYS */;
INSERT INTO `world_cup` VALUES (0,1930,15,'1st',13,39,14,2,31),(1,1934,7,'2nd',16,18,52,8,26),(2,1938,1,'3rd',15,18,57,4,5),(3,1950,5,'4th',13,39,4,5,9),(4,1954,14,'5th',16,8,57,26,39),(5,1958,13,'6th',16,4,5,27,8),(6,1962,12,'7th',16,4,52,25,31),(7,1966,11,'8th',16,33,8,44,6),(8,1970,8,'9th',16,4,18,8,39),(9,1974,3,'10th',16,8,20,45,4),(10,1978,10,'11th',16,14,20,4,18),(11,1982,9,'12th',24,18,8,45,27),(12,1986,8,'13th',24,14,8,27,22),(13,1990,7,'14th',24,8,14,18,33),(14,1994,0,'15th',24,4,18,5,13),(15,1998,1,'16th',32,27,4,35,20),(16,2002,2,'17th',32,4,8,41,10),(17,2006,3,'18th',32,18,27,8,44),(18,2010,4,'19th',32,9,20,8,39),(19,2014,5,'20th',32,8,14,20,4),(20,2018,6,'21th',32,27,35,22,33),(21,2022,16,'22th',32,NULL,NULL,NULL,NULL),(22,2026,17,'23th',64,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `world_cup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `2002_wc_finalists_campaigns_view`
--

/*!50001 DROP VIEW IF EXISTS `2002_wc_finalists_campaigns_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `2002_wc_finalists_campaigns_view` AS select `g`.`description` AS `STAGE`,`g`.`data` AS `DATA`,`s`.`name` AS `Stadium`,concat(`th`.`name`,' ',`g`.`home_score`,' x ',`g`.`away_score`,' ',`ta`.`name`) AS `Match Result` from (((((`game` `g` join `world_cup` `wc` on(((`wc`.`id_world_cup` = `g`.`world_cup_id`) and (`wc`.`year` = 2002)))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `stadium` `s` on((`s`.`id_stadium` = `g`.`stadium_id`))) join `team` `th` on((`th`.`id_team` = `g`.`home_team_id`))) join `team` `ta` on((`ta`.`id_team` = `g`.`away_team_id`))) where ((`g`.`home_team_id` = 4) or (`g`.`away_team_id` = 4) or (`g`.`home_team_id` = 8) or (`g`.`away_team_id` = 8)) order by `g`.`data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `2002_wc_r9_goals_2_view`
--

/*!50001 DROP VIEW IF EXISTS `2002_wc_r9_goals_2_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `2002_wc_r9_goals_2_view` AS select `g`.`description` AS `DESCRIPTION`,group_concat(`goal`.`minuto` separator ', ') AS `MINUTOS DOS GOLS`,`t`.`name` AS `OPPONENT`,concat(`th`.`name`,' ',`g`.`home_score`,' x ',`g`.`away_score`,' ',`ta`.`name`) AS `FINAL SCORE` from (((((`goal` join `game` `g` on((`g`.`id_game` = `goal`.`game_id`))) join `player` `p` on((`p`.`id_player` = `goal`.`player_id`))) join `team` `t` on((((`t`.`id_team` = `g`.`home_team_id`) and (`g`.`home_team_id` <> `p`.`team_id`)) or ((`t`.`id_team` = `g`.`away_team_id`) and (`g`.`away_team_id` <> `p`.`team_id`))))) join `team` `th` on((`th`.`id_team` = `g`.`home_team_id`))) join `team` `ta` on((`ta`.`id_team` = `g`.`away_team_id`))) where ((`goal`.`player_id` = 0) and (`g`.`world_cup_id` = 16)) group by `g`.`id_game` order by `g`.`data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `2002_wc_top_goalscorers_view`
--

/*!50001 DROP VIEW IF EXISTS `2002_wc_top_goalscorers_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `2002_wc_top_goalscorers_view` AS select `p`.`name` AS `PLAYER`,`t`.`name` AS `TEAM`,count(0) AS `GOALS` from ((((`goal` `g` join `game` `gm` on((`g`.`game_id` = `gm`.`id_game`))) join `world_cup` `wc` on((`gm`.`world_cup_id` = `wc`.`id_world_cup`))) join `player` `p` on((`g`.`player_id` = `p`.`id_player`))) join `team` `t` on((`p`.`team_id` = `t`.`id_team`))) where (`wc`.`year` = 2002) group by `p`.`id_player` order by `GOALS` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `boot_winners`
--

/*!50001 DROP VIEW IF EXISTS `boot_winners`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `boot_winners` AS select concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `WORLD CUP`,group_concat(distinct `pgb`.`name` separator ' / ') AS `GOLDEN BOOT`,group_concat(distinct `pss`.`name` separator ' / ') AS `SILVER SHOE`,group_concat(distinct `pbs`.`name` separator ' / ') AS `BRONZE SHOE` from (((((((`world_cup` `wc` join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) left join `golden_boot` `gb` on((`gb`.`world_cup_id` = `wc`.`id_world_cup`))) left join `silver_shoe` `ss` on((`ss`.`world_cup_id` = `wc`.`id_world_cup`))) left join `bronze_shoe` `bs` on((`bs`.`world_cup_id` = `wc`.`id_world_cup`))) left join `player` `pgb` on((`pgb`.`id_player` = `gb`.`player_id`))) left join `player` `pss` on((`pss`.`id_player` = `ss`.`player_id`))) left join `player` `pbs` on((`pbs`.`id_player` = `bs`.`player_id`))) where (`wc`.`year` < year(curdate())) group by `wc`.`year` order by `wc`.`year` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `every_goleada_view`
--

/*!50001 DROP VIEW IF EXISTS `every_goleada_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `every_goleada_view` AS select concat(`wc`.`year`,' FIFA World Cup ',`c`.`name`) AS `World Cup`,`g`.`description` AS `STAGE`,`g`.`data` AS `DATA`,concat(`th`.`name`,' ',`g`.`home_score`,' x ',`g`.`away_score`,' ',`ta`.`name`) AS `RESULT` from ((((`game` `g` join `world_cup` `wc` on((`wc`.`id_world_cup` = `g`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `team` `th` on((`th`.`id_team` = `g`.`home_team_id`))) join `team` `ta` on((`ta`.`id_team` = `g`.`away_team_id`))) where (abs((`g`.`home_score` - `g`.`away_score`)) > 2) order by `g`.`data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_best_young_player`
--

/*!50001 DROP VIEW IF EXISTS `view_table_best_young_player`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_best_young_player` AS select `byp`.`id_best_young_player` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`p`.`name` AS `Winner` from (((`best_young_player` `byp` left join `world_cup` `wc` on((`wc`.`id_world_cup` = `byp`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) left join `player` `p` on((`p`.`id_player` = `byp`.`player_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_extra_time`
--

/*!50001 DROP VIEW IF EXISTS `view_table_extra_time`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_extra_time` AS select `et`.`id_extra_time` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' ',`gm`.`home_score`,' x ',`gm`.`away_score`,' ',`t2`.`name`) AS `Score at Regular Time`,concat(`t1`.`name`,' ',`et`.`home_score`,' x ',`et`.`away_score`,' ',`t2`.`name`) AS `Score at Extra Time` from (((((`extra_time` `et` join `game` `gm` on((`gm`.`id_game` = `et`.`game_id`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_game`
--

/*!50001 DROP VIEW IF EXISTS `view_table_game`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_game` AS select `team`.`id_team` AS `ID`,`team`.`name` AS `Team`,`team`.`confederation` AS `Confederation`,`team`.`participations` AS `Participations`,(select count(`wc`.`champion`) from `world_cup` `wc` where (`wc`.`champion` = `team`.`id_team`)) AS `Titles`,(select count(`wc`.`runner_up`) from `world_cup` `wc` where (`wc`.`runner_up` = `team`.`id_team`)) AS `2nd Places`,(select count(`wc`.`third_place`) from `world_cup` `wc` where (`wc`.`third_place` = `team`.`id_team`)) AS `3rd Places`,(select count(`wc`.`fourth_place`) from `world_cup` `wc` where (`wc`.`fourth_place` = `team`.`id_team`)) AS `4th Places`,`team`.`games` AS `Games`,`team`.`wins` AS `Wins`,`team`.`draws` AS `Draws`,`team`.`losses` AS `Losses`,`team`.`goals_scored` AS `Goals Scored`,`team`.`goals_against` AS `Goals Against`,(`team`.`goals_scored` - `team`.`goals_against`) AS `Saldo de Gols` from `team` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_goal`
--

/*!50001 DROP VIEW IF EXISTS `view_table_goal`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_goal` AS select `g`.`id_goal` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' x ',`t2`.`name`) AS `Game`,concat(`p`.`name`,' (',`t`.`name`,')') AS `Goalscorer`,`g`.`minuto` AS `Minuto` from (((((((`goal` `g` join `game` `gm` on((`gm`.`id_game` = `g`.`game_id`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `player` `p` on((`p`.`id_player` = `g`.`player_id`))) join `team` `t` on((`t`.`id_team` = `p`.`team_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_golden_glove`
--

/*!50001 DROP VIEW IF EXISTS `view_table_golden_glove`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_golden_glove` AS select `gg`.`id_golden_glove` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`p`.`name` AS `Winner` from (((`golden_glove` `gg` left join `world_cup` `wc` on((`wc`.`id_world_cup` = `gg`.`world_cup_id`))) left join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) left join `player` `p` on((`p`.`id_player` = `gg`.`player_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_own_goal`
--

/*!50001 DROP VIEW IF EXISTS `view_table_own_goal`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_own_goal` AS select `og`.`id_own_goal` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' x ',`t2`.`name`) AS `Game`,concat(`p`.`name`,' (',`t`.`name`,')') AS `Goalscorer`,`og`.`minuto` AS `Minuto` from (((((((`own_goal` `og` join `game` `gm` on((`gm`.`id_game` = `og`.`game_id`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `player` `p` on((`p`.`id_player` = `og`.`player_id`))) join `team` `t` on((`t`.`id_team` = `p`.`team_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_penalty`
--

/*!50001 DROP VIEW IF EXISTS `view_table_penalty`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_penalty` AS select `pk`.`id_penalty` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' ',`gm`.`home_score`,' x ',`gm`.`away_score`,' ',`t2`.`name`) AS `Score at Regular Time`,concat(`t1`.`name`,' ',`et`.`home_score`,' x ',`et`.`away_score`,' ',`t2`.`name`) AS `Score at Extra Time`,concat(`t1`.`name`,' ',`pk`.`home_score`,' x ',`pk`.`away_score`,' ',`t2`.`name`) AS `Penalties` from ((((((`penalty` `pk` join `game` `gm` on((`gm`.`id_game` = `pk`.`game_id`))) join `extra_time` `et` on((`et`.`game_id` = `gm`.`id_game`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_stadium`
--

/*!50001 DROP VIEW IF EXISTS `view_table_stadium`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_stadium` AS select `s`.`id_stadium` AS `ID`,`s`.`name` AS `Name`,`s`.`capacity` AS `Capacity`,`c`.`name` AS `City` from (`stadium` `s` join `city` `c` on((`c`.`id_city` = `s`.`city_id`))) order by `s`.`id_stadium` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:16:55
