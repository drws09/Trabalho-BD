CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `world_cup`
--

DROP TABLE IF EXISTS `world_cup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `world_cup` (
  `id_world_cup` int NOT NULL,
  `year` smallint DEFAULT NULL,
  `host_id` int DEFAULT NULL,
  `edition` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `number_participants` smallint DEFAULT NULL,
  `champion` int DEFAULT NULL,
  `runner_up` int DEFAULT NULL,
  `third_place` int DEFAULT NULL,
  `fourth_place` int DEFAULT NULL,
  PRIMARY KEY (`id_world_cup`),
  KEY `host_id` (`host_id`),
  KEY `champion` (`champion`),
  KEY `runner_up` (`runner_up`),
  KEY `third_place` (`third_place`),
  KEY `fourth_place` (`fourth_place`),
  CONSTRAINT `world_cup_ibfk_1` FOREIGN KEY (`host_id`) REFERENCES `country` (`id_host`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_2` FOREIGN KEY (`champion`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_3` FOREIGN KEY (`runner_up`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_4` FOREIGN KEY (`third_place`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `world_cup_ibfk_5` FOREIGN KEY (`fourth_place`) REFERENCES `team` (`id_team`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world_cup`
--

LOCK TABLES `world_cup` WRITE;
/*!40000 ALTER TABLE `world_cup` DISABLE KEYS */;
INSERT INTO `world_cup` VALUES (0,1930,15,'1st',13,39,14,2,31),(1,1934,7,'2nd',16,18,52,8,26),(2,1938,1,'3rd',15,18,57,4,5),(3,1950,5,'4th',13,39,4,5,9),(4,1954,14,'5th',16,8,57,26,39),(5,1958,13,'6th',16,4,5,27,8),(6,1962,12,'7th',16,4,52,25,31),(7,1966,11,'8th',16,33,8,44,6),(8,1970,8,'9th',16,4,18,8,39),(9,1974,3,'10th',16,8,20,45,4),(10,1978,10,'11th',16,14,20,4,18),(11,1982,9,'12th',24,18,8,45,27),(12,1986,8,'13th',24,14,8,27,22),(13,1990,7,'14th',24,8,14,18,33),(14,1994,0,'15th',24,4,18,5,13),(15,1998,1,'16th',32,27,4,35,20),(16,2002,2,'17th',32,4,8,41,10),(17,2006,3,'18th',32,18,27,8,44),(18,2010,4,'19th',32,9,20,8,39),(19,2014,5,'20th',32,8,14,20,4),(20,2018,6,'21th',32,27,35,22,33),(21,2022,16,'22th',32,NULL,NULL,NULL,NULL),(22,2026,17,'23th',64,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `world_cup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:17
