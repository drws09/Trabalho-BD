CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `view_table_game`
--

DROP TABLE IF EXISTS `view_table_game`;
/*!50001 DROP VIEW IF EXISTS `view_table_game`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_game` AS SELECT 
 1 AS `ID`,
 1 AS `Team`,
 1 AS `Confederation`,
 1 AS `Participations`,
 1 AS `Titles`,
 1 AS `2nd Places`,
 1 AS `3rd Places`,
 1 AS `4th Places`,
 1 AS `Games`,
 1 AS `Wins`,
 1 AS `Draws`,
 1 AS `Losses`,
 1 AS `Goals Scored`,
 1 AS `Goals Against`,
 1 AS `Saldo de Gols`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_penalty`
--

DROP TABLE IF EXISTS `view_table_penalty`;
/*!50001 DROP VIEW IF EXISTS `view_table_penalty`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_penalty` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Score at Regular Time`,
 1 AS `Score at Extra Time`,
 1 AS `Penalties`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_stadium`
--

DROP TABLE IF EXISTS `view_table_stadium`;
/*!50001 DROP VIEW IF EXISTS `view_table_stadium`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_stadium` AS SELECT 
 1 AS `ID`,
 1 AS `Name`,
 1 AS `Capacity`,
 1 AS `City`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `2002_wc_r9_goals_2_view`
--

DROP TABLE IF EXISTS `2002_wc_r9_goals_2_view`;
/*!50001 DROP VIEW IF EXISTS `2002_wc_r9_goals_2_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `2002_wc_r9_goals_2_view` AS SELECT 
 1 AS `DESCRIPTION`,
 1 AS `MINUTOS DOS GOLS`,
 1 AS `OPPONENT`,
 1 AS `FINAL SCORE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `2002_wc_finalists_campaigns_view`
--

DROP TABLE IF EXISTS `2002_wc_finalists_campaigns_view`;
/*!50001 DROP VIEW IF EXISTS `2002_wc_finalists_campaigns_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `2002_wc_finalists_campaigns_view` AS SELECT 
 1 AS `STAGE`,
 1 AS `DATA`,
 1 AS `Stadium`,
 1 AS `Match Result`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_own_goal`
--

DROP TABLE IF EXISTS `view_table_own_goal`;
/*!50001 DROP VIEW IF EXISTS `view_table_own_goal`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_own_goal` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Game`,
 1 AS `Goalscorer`,
 1 AS `Minuto`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_best_young_player`
--

DROP TABLE IF EXISTS `view_table_best_young_player`;
/*!50001 DROP VIEW IF EXISTS `view_table_best_young_player`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_best_young_player` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Winner`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_extra_time`
--

DROP TABLE IF EXISTS `view_table_extra_time`;
/*!50001 DROP VIEW IF EXISTS `view_table_extra_time`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_extra_time` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Score at Regular Time`,
 1 AS `Score at Extra Time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `boot_winners`
--

DROP TABLE IF EXISTS `boot_winners`;
/*!50001 DROP VIEW IF EXISTS `boot_winners`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `boot_winners` AS SELECT 
 1 AS `WORLD CUP`,
 1 AS `GOLDEN BOOT`,
 1 AS `SILVER SHOE`,
 1 AS `BRONZE SHOE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_goal`
--

DROP TABLE IF EXISTS `view_table_goal`;
/*!50001 DROP VIEW IF EXISTS `view_table_goal`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_goal` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Round`,
 1 AS `Game`,
 1 AS `Goalscorer`,
 1 AS `Minuto`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `every_goleada_view`
--

DROP TABLE IF EXISTS `every_goleada_view`;
/*!50001 DROP VIEW IF EXISTS `every_goleada_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `every_goleada_view` AS SELECT 
 1 AS `World Cup`,
 1 AS `STAGE`,
 1 AS `DATA`,
 1 AS `RESULT`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `2002_wc_top_goalscorers_view`
--

DROP TABLE IF EXISTS `2002_wc_top_goalscorers_view`;
/*!50001 DROP VIEW IF EXISTS `2002_wc_top_goalscorers_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `2002_wc_top_goalscorers_view` AS SELECT 
 1 AS `PLAYER`,
 1 AS `TEAM`,
 1 AS `GOALS`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_table_golden_glove`
--

DROP TABLE IF EXISTS `view_table_golden_glove`;
/*!50001 DROP VIEW IF EXISTS `view_table_golden_glove`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_table_golden_glove` AS SELECT 
 1 AS `ID`,
 1 AS `World Cup`,
 1 AS `Winner`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_table_game`
--

/*!50001 DROP VIEW IF EXISTS `view_table_game`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_game` AS select `team`.`id_team` AS `ID`,`team`.`name` AS `Team`,`team`.`confederation` AS `Confederation`,`team`.`participations` AS `Participations`,(select count(`wc`.`champion`) from `world_cup` `wc` where (`wc`.`champion` = `team`.`id_team`)) AS `Titles`,(select count(`wc`.`runner_up`) from `world_cup` `wc` where (`wc`.`runner_up` = `team`.`id_team`)) AS `2nd Places`,(select count(`wc`.`third_place`) from `world_cup` `wc` where (`wc`.`third_place` = `team`.`id_team`)) AS `3rd Places`,(select count(`wc`.`fourth_place`) from `world_cup` `wc` where (`wc`.`fourth_place` = `team`.`id_team`)) AS `4th Places`,`team`.`games` AS `Games`,`team`.`wins` AS `Wins`,`team`.`draws` AS `Draws`,`team`.`losses` AS `Losses`,`team`.`goals_scored` AS `Goals Scored`,`team`.`goals_against` AS `Goals Against`,(`team`.`goals_scored` - `team`.`goals_against`) AS `Saldo de Gols` from `team` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_penalty`
--

/*!50001 DROP VIEW IF EXISTS `view_table_penalty`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_penalty` AS select `pk`.`id_penalty` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' ',`gm`.`home_score`,' x ',`gm`.`away_score`,' ',`t2`.`name`) AS `Score at Regular Time`,concat(`t1`.`name`,' ',`et`.`home_score`,' x ',`et`.`away_score`,' ',`t2`.`name`) AS `Score at Extra Time`,concat(`t1`.`name`,' ',`pk`.`home_score`,' x ',`pk`.`away_score`,' ',`t2`.`name`) AS `Penalties` from ((((((`penalty` `pk` join `game` `gm` on((`gm`.`id_game` = `pk`.`game_id`))) join `extra_time` `et` on((`et`.`game_id` = `gm`.`id_game`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_stadium`
--

/*!50001 DROP VIEW IF EXISTS `view_table_stadium`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_stadium` AS select `s`.`id_stadium` AS `ID`,`s`.`name` AS `Name`,`s`.`capacity` AS `Capacity`,`c`.`name` AS `City` from (`stadium` `s` join `city` `c` on((`c`.`id_city` = `s`.`city_id`))) order by `s`.`id_stadium` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `2002_wc_r9_goals_2_view`
--

/*!50001 DROP VIEW IF EXISTS `2002_wc_r9_goals_2_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `2002_wc_r9_goals_2_view` AS select `g`.`description` AS `DESCRIPTION`,group_concat(`goal`.`minuto` separator ', ') AS `MINUTOS DOS GOLS`,`t`.`name` AS `OPPONENT`,concat(`th`.`name`,' ',`g`.`home_score`,' x ',`g`.`away_score`,' ',`ta`.`name`) AS `FINAL SCORE` from (((((`goal` join `game` `g` on((`g`.`id_game` = `goal`.`game_id`))) join `player` `p` on((`p`.`id_player` = `goal`.`player_id`))) join `team` `t` on((((`t`.`id_team` = `g`.`home_team_id`) and (`g`.`home_team_id` <> `p`.`team_id`)) or ((`t`.`id_team` = `g`.`away_team_id`) and (`g`.`away_team_id` <> `p`.`team_id`))))) join `team` `th` on((`th`.`id_team` = `g`.`home_team_id`))) join `team` `ta` on((`ta`.`id_team` = `g`.`away_team_id`))) where ((`goal`.`player_id` = 0) and (`g`.`world_cup_id` = 16)) group by `g`.`id_game` order by `g`.`data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `2002_wc_finalists_campaigns_view`
--

/*!50001 DROP VIEW IF EXISTS `2002_wc_finalists_campaigns_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `2002_wc_finalists_campaigns_view` AS select `g`.`description` AS `STAGE`,`g`.`data` AS `DATA`,`s`.`name` AS `Stadium`,concat(`th`.`name`,' ',`g`.`home_score`,' x ',`g`.`away_score`,' ',`ta`.`name`) AS `Match Result` from (((((`game` `g` join `world_cup` `wc` on(((`wc`.`id_world_cup` = `g`.`world_cup_id`) and (`wc`.`year` = 2002)))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `stadium` `s` on((`s`.`id_stadium` = `g`.`stadium_id`))) join `team` `th` on((`th`.`id_team` = `g`.`home_team_id`))) join `team` `ta` on((`ta`.`id_team` = `g`.`away_team_id`))) where ((`g`.`home_team_id` = 4) or (`g`.`away_team_id` = 4) or (`g`.`home_team_id` = 8) or (`g`.`away_team_id` = 8)) order by `g`.`data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_own_goal`
--

/*!50001 DROP VIEW IF EXISTS `view_table_own_goal`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_own_goal` AS select `og`.`id_own_goal` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' x ',`t2`.`name`) AS `Game`,concat(`p`.`name`,' (',`t`.`name`,')') AS `Goalscorer`,`og`.`minuto` AS `Minuto` from (((((((`own_goal` `og` join `game` `gm` on((`gm`.`id_game` = `og`.`game_id`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `player` `p` on((`p`.`id_player` = `og`.`player_id`))) join `team` `t` on((`t`.`id_team` = `p`.`team_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_best_young_player`
--

/*!50001 DROP VIEW IF EXISTS `view_table_best_young_player`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_best_young_player` AS select `byp`.`id_best_young_player` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`p`.`name` AS `Winner` from (((`best_young_player` `byp` left join `world_cup` `wc` on((`wc`.`id_world_cup` = `byp`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) left join `player` `p` on((`p`.`id_player` = `byp`.`player_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_extra_time`
--

/*!50001 DROP VIEW IF EXISTS `view_table_extra_time`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_extra_time` AS select `et`.`id_extra_time` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' ',`gm`.`home_score`,' x ',`gm`.`away_score`,' ',`t2`.`name`) AS `Score at Regular Time`,concat(`t1`.`name`,' ',`et`.`home_score`,' x ',`et`.`away_score`,' ',`t2`.`name`) AS `Score at Extra Time` from (((((`extra_time` `et` join `game` `gm` on((`gm`.`id_game` = `et`.`game_id`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `boot_winners`
--

/*!50001 DROP VIEW IF EXISTS `boot_winners`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `boot_winners` AS select concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `WORLD CUP`,group_concat(distinct `pgb`.`name` separator ' / ') AS `GOLDEN BOOT`,group_concat(distinct `pss`.`name` separator ' / ') AS `SILVER SHOE`,group_concat(distinct `pbs`.`name` separator ' / ') AS `BRONZE SHOE` from (((((((`world_cup` `wc` join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) left join `golden_boot` `gb` on((`gb`.`world_cup_id` = `wc`.`id_world_cup`))) left join `silver_shoe` `ss` on((`ss`.`world_cup_id` = `wc`.`id_world_cup`))) left join `bronze_shoe` `bs` on((`bs`.`world_cup_id` = `wc`.`id_world_cup`))) left join `player` `pgb` on((`pgb`.`id_player` = `gb`.`player_id`))) left join `player` `pss` on((`pss`.`id_player` = `ss`.`player_id`))) left join `player` `pbs` on((`pbs`.`id_player` = `bs`.`player_id`))) where (`wc`.`year` < year(curdate())) group by `wc`.`year` order by `wc`.`year` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_goal`
--

/*!50001 DROP VIEW IF EXISTS `view_table_goal`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_goal` AS select `g`.`id_goal` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`gm`.`description` AS `Round`,concat(`t1`.`name`,' x ',`t2`.`name`) AS `Game`,concat(`p`.`name`,' (',`t`.`name`,')') AS `Goalscorer`,`g`.`minuto` AS `Minuto` from (((((((`goal` `g` join `game` `gm` on((`gm`.`id_game` = `g`.`game_id`))) join `team` `t1` on((`t1`.`id_team` = `gm`.`home_team_id`))) join `team` `t2` on((`t2`.`id_team` = `gm`.`away_team_id`))) join `world_cup` `wc` on((`wc`.`id_world_cup` = `gm`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `player` `p` on((`p`.`id_player` = `g`.`player_id`))) join `team` `t` on((`t`.`id_team` = `p`.`team_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `every_goleada_view`
--

/*!50001 DROP VIEW IF EXISTS `every_goleada_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `every_goleada_view` AS select concat(`wc`.`year`,' FIFA World Cup ',`c`.`name`) AS `World Cup`,`g`.`description` AS `STAGE`,`g`.`data` AS `DATA`,concat(`th`.`name`,' ',`g`.`home_score`,' x ',`g`.`away_score`,' ',`ta`.`name`) AS `RESULT` from ((((`game` `g` join `world_cup` `wc` on((`wc`.`id_world_cup` = `g`.`world_cup_id`))) join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) join `team` `th` on((`th`.`id_team` = `g`.`home_team_id`))) join `team` `ta` on((`ta`.`id_team` = `g`.`away_team_id`))) where (abs((`g`.`home_score` - `g`.`away_score`)) > 2) order by `g`.`data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `2002_wc_top_goalscorers_view`
--

/*!50001 DROP VIEW IF EXISTS `2002_wc_top_goalscorers_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `2002_wc_top_goalscorers_view` AS select `p`.`name` AS `PLAYER`,`t`.`name` AS `TEAM`,count(0) AS `GOALS` from ((((`goal` `g` join `game` `gm` on((`g`.`game_id` = `gm`.`id_game`))) join `world_cup` `wc` on((`gm`.`world_cup_id` = `wc`.`id_world_cup`))) join `player` `p` on((`g`.`player_id` = `p`.`id_player`))) join `team` `t` on((`p`.`team_id` = `t`.`id_team`))) where (`wc`.`year` = 2002) group by `p`.`id_player` order by `GOALS` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_table_golden_glove`
--

/*!50001 DROP VIEW IF EXISTS `view_table_golden_glove`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_table_golden_glove` AS select `gg`.`id_golden_glove` AS `ID`,concat(`wc`.`year`,' World Cup ',`c`.`name`) AS `World Cup`,`p`.`name` AS `Winner` from (((`golden_glove` `gg` left join `world_cup` `wc` on((`wc`.`id_world_cup` = `gg`.`world_cup_id`))) left join `country` `c` on((`c`.`id_host` = `wc`.`host_id`))) left join `player` `p` on((`p`.`id_player` = `gg`.`player_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:18
