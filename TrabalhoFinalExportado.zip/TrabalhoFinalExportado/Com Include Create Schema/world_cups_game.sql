CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game` (
  `id_game` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `description` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data` date DEFAULT NULL,
  `stadium_id` int DEFAULT NULL,
  `attendance` int DEFAULT NULL,
  `referee_id` int DEFAULT NULL,
  `home_team_id` int DEFAULT NULL,
  `away_team_id` int DEFAULT NULL,
  `home_coach_id` int DEFAULT NULL,
  `away_coach_id` int DEFAULT NULL,
  `home_score` smallint DEFAULT NULL,
  `away_score` smallint DEFAULT NULL,
  PRIMARY KEY (`id_game`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `stadium_id` (`stadium_id`),
  KEY `referee_id` (`referee_id`),
  KEY `home_team_id` (`home_team_id`),
  KEY `away_team_id` (`away_team_id`),
  KEY `home_coach_id` (`home_coach_id`),
  KEY `away_coach_id` (`away_coach_id`),
  CONSTRAINT `game_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_2` FOREIGN KEY (`stadium_id`) REFERENCES `stadium` (`id_stadium`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_3` FOREIGN KEY (`referee_id`) REFERENCES `referee` (`id_referee`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_4` FOREIGN KEY (`home_team_id`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_5` FOREIGN KEY (`away_team_id`) REFERENCES `team` (`id_team`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_6` FOREIGN KEY (`home_coach_id`) REFERENCES `coach` (`id_coach`) ON DELETE CASCADE,
  CONSTRAINT `game_ibfk_7` FOREIGN KEY (`away_coach_id`) REFERENCES `coach` (`id_coach`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
INSERT INTO `game` VALUES (0,16,'Final','2002-06-30',22,69029,0,8,4,0,1,0,2),(1,17,'Final','2006-07-09',0,69000,1,18,27,2,3,1,1),(2,18,'Final','2010-07-11',51,84490,2,20,9,4,5,0,0),(3,19,'Final','2014-07-13',52,74738,3,8,14,6,7,0,0),(4,20,'Final','2018-07-15',53,78011,4,27,35,8,9,4,2),(5,15,'Final','1998-07-12',32,75000,5,4,27,13,11,0,3),(6,14,'Final','1994-07-17',42,94194,6,4,18,12,10,0,0),(7,13,'Final','1990-07-08',54,73603,7,8,14,14,15,1,0),(8,12,'Final','1986-06-29',55,114600,8,14,8,15,14,3,2),(9,11,'Final','1982-07-11',56,90000,9,18,8,16,17,3,1),(10,10,'Final','1978-06-25',57,71483,10,14,20,18,19,1,1),(11,9,'Final','1974-07-07',58,75200,11,20,8,20,21,1,2),(12,8,'Final','1970-06-21',55,107412,12,4,18,13,22,4,1),(13,7,'Final','1966-07-30',59,96924,13,33,8,23,21,2,2),(14,6,'Final','1962-06-17',60,68679,14,4,52,24,25,3,1),(15,5,'Final','1958-06-29',61,49737,15,4,5,26,27,5,2),(16,4,'Final','1954-07-04',62,62500,16,8,57,28,29,3,2),(17,3,'Final *2nd Group Stage','1950-07-16',52,173850,17,39,4,30,31,2,1),(18,2,'Final','1938-06-19',63,45000,18,18,57,32,33,4,2),(19,1,'Final','1934-06-10',64,55000,19,18,52,32,34,1,1),(20,0,'Final','1930-07-30',65,68346,20,39,14,35,36,4,2),(21,16,'Group Stage (Group C)','2002-06-03',16,33842,21,4,41,1,37,2,1),(22,16,'Group Stage (Group C)','2002-06-08',20,36750,22,4,43,1,38,4,0),(23,16,'Group Stage (Group C)','2002-06-13',17,38524,23,42,4,39,1,2,5),(24,16,'Round of 16','2002-06-17',30,40440,24,4,22,1,40,2,0),(25,16,'Quarter Final','2002-06-21',24,47436,25,33,4,41,1,1,2),(26,16,'Semi Final','2002-06-26',23,61058,26,4,41,1,37,1,0),(27,16,'Group Stage (Group E)','2002-06-01',31,32218,27,8,21,0,42,8,0),(28,16,'Group Stage (Group E)','2002-06-05',29,35854,26,8,17,0,43,1,1),(29,16,'Group Stage (Group E)','2002-06-11',24,47085,28,7,8,44,0,0,2),(30,16,'Round of 16','2002-06-15',20,25176,29,8,30,0,45,1,0),(31,16,'Quarter Final','2002-06-21',16,37337,30,8,2,0,46,1,0),(32,16,'Semi Final','2002-06-25',13,65256,31,8,10,0,47,1,0),(33,16,'Third Place Match','2002-06-29',12,63483,32,10,41,47,37,2,3),(34,17,'Third Place Match','2006-07-08',3,52000,33,8,44,48,1,3,1),(35,17,'Group Stage (Group E)','2006-06-12',9,43000,34,18,51,2,49,2,0),(36,17,'Group Stage (Group E)','2006-06-17',7,46000,35,18,2,2,46,1,1),(37,17,'Group Stage (Group E)','2006-06-22',5,50000,36,52,18,50,2,0,2),(38,17,'Round of 16','2006-06-26',7,46000,37,18,53,2,47,1,0),(39,17,'Quarter Final','2006-06-30',5,50000,38,18,55,2,51,3,0),(40,17,'Semi Final','2006-07-04',2,65000,36,8,18,48,2,0,0),(41,17,'Group Stage - Group G','2006-06-13',3,52000,39,27,1,3,52,0,0),(42,17,'Group Stage - Group G','2006-06-18',10,43000,36,27,10,3,53,1,1),(43,17,'Group Stage - Group G','2006-06-23',8,45000,35,54,27,54,3,0,2),(44,17,'Round of 16','2006-06-27',9,43000,40,9,27,55,3,1,3),(45,17,'Quarter Final','2006-07-01',6,48000,37,4,27,12,3,0,1),(46,17,'Semi Final','2006-07-05',1,66000,35,44,27,1,3,0,1),(47,17,'Quarter Final','2006-06-30',0,72000,41,8,14,48,56,1,1),(48,17,'Quarter Final','2006-07-01',4,52000,1,33,44,1,41,0,0),(49,17,'Round of 16','2006-06-24',10,43000,42,14,16,56,57,1,1),(50,17,'Round of 16','2006-06-26',8,45000,36,1,55,52,51,0,0),(51,16,'Quarter Final','2002-06-22',18,42114,23,9,10,58,47,0,0),(52,16,'Quarter Final','2002-06-22',25,44233,43,38,41,59,37,0,0),(53,16,'Round of 16','2002-06-16',17,38926,22,9,17,58,43,1,1),(54,16,'Round of 16','2002-06-18',21,38588,44,10,18,47,60,1,1),(55,16,'Round of 16','2002-06-16',27,39747,27,5,38,61,59,1,1),(56,15,'Semi Final','1998-07-07',33,56200,45,4,20,13,47,1,1),(57,15,'Quarter Final','1998-07-03',32,77000,30,18,27,45,11,0,0),(58,15,'Round of 16','1998-06-30',39,30600,26,14,33,62,63,2,2),(59,15,'Round of 16','1998-06-28',36,31800,45,27,30,11,64,0,0),(60,14,'Quarter Final','1994-07-10',43,83500,46,0,5,66,65,1,1),(61,14,'Round of 16','1994-07-05',45,71030,47,16,13,67,68,1,1),(62,14,'Round of 16','1994-07-05',49,54367,48,12,18,69,10,1,1),(63,13,'Semi Final','1990-07-04',66,62628,49,8,33,14,70,1,1),(64,13,'Semi Final','1990-07-03',67,59978,50,18,14,71,15,1,1),(65,13,'Quarter Final','1990-06-30',68,38971,51,31,14,72,15,0,0),(66,17,'Group Stage (Group B)','2006-06-10',6,48000,52,33,30,41,73,1,0),(67,17,'Group Stage (Group B)','2006-06-20',7,46000,40,30,47,73,74,2,0),(68,16,'Group Stage (Group B)','2002-06-07',19,24000,23,9,30,58,45,3,1),(69,16,'Group Stage (Group D)','2002-06-05',17,37306,44,2,44,46,83,3,2),(70,15,'Group Stage (Group D)','1998-06-24',36,38100,53,9,13,75,76,6,1),(71,15,'Group Stage (Group F)','1998-06-21',36,38100,26,8,31,77,78,2,2),(72,15,'Group Stage (Group D)','1998-06-13',37,35500,54,9,12,75,38,2,3),(73,15,'Group Stage (Group C)','1998-06-12',33,55000,55,27,29,11,79,3,0),(74,15,'Group Stage (Group A)','1998-06-10',41,29800,56,23,19,80,81,2,2),(75,15,'Group Stage (Group A)','1998-06-10',32,80000,57,4,24,13,82,2,1),(76,18,'Group Stage (Group E)','2010-06-14',51,83465,58,20,28,4,84,2,0),(77,18,'Group Stage (Group B)','2010-06-17',51,82174,38,14,10,85,86,4,1);
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:17
