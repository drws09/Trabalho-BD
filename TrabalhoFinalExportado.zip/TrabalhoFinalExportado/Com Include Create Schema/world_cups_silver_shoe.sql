CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `silver_shoe`
--

DROP TABLE IF EXISTS `silver_shoe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `silver_shoe` (
  `id_Silver_Shoe` int NOT NULL,
  `world_cup_id` int DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  `games` smallint DEFAULT NULL,
  `goals` smallint DEFAULT NULL,
  PRIMARY KEY (`id_Silver_Shoe`),
  KEY `world_cup_id` (`world_cup_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `silver_shoe_ibfk_1` FOREIGN KEY (`world_cup_id`) REFERENCES `world_cup` (`id_world_cup`) ON DELETE CASCADE,
  CONSTRAINT `silver_shoe_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `player` (`id_player`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `silver_shoe`
--

LOCK TABLES `silver_shoe` WRITE;
/*!40000 ALTER TABLE `silver_shoe` DISABLE KEYS */;
INSERT INTO `silver_shoe` VALUES (0,0,73,4,5),(1,1,74,4,4),(2,1,75,4,4),(3,2,76,4,5),(4,2,77,4,5),(5,2,78,4,5),(6,3,79,4,5),(7,4,80,5,6),(8,4,81,3,6),(9,4,82,5,6),(10,5,83,4,6),(11,5,10,4,6),(12,6,NULL,NULL,NULL),(13,7,84,5,6),(14,8,27,6,7),(15,9,24,7,5),(16,9,85,6,5),(17,10,86,6,5),(18,11,47,7,5),(19,12,87,5,5),(20,12,88,5,5),(21,12,31,7,5),(22,13,89,5,5),(23,14,NULL,NULL,NULL),(24,15,90,5,5),(25,15,91,5,5),(26,16,92,7,5),(27,16,70,7,5),(28,17,93,4,3),(29,18,52,7,5),(30,19,44,7,5),(31,20,7,7,4);
/*!40000 ALTER TABLE `silver_shoe` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:15
