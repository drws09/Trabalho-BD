CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `referee`
--

DROP TABLE IF EXISTS `referee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referee` (
  `id_referee` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nationality` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_referee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referee`
--

LOCK TABLES `referee` WRITE;
/*!40000 ALTER TABLE `referee` DISABLE KEYS */;
INSERT INTO `referee` VALUES (0,'Pierluigi Collina','Italy'),(1,'Horacio Elizondo','Argentina'),(2,'Howard Webb','England'),(3,'Nicola Rizzoli','Italy'),(4,'Nestor Pitana','Argentina'),(5,'Said Belqola','Morocco'),(6,'Sandor Puhl','Hungary'),(7,'Edgardo Codesal','Mexico'),(8,'Romualdo Arppi Filho','Brazil'),(9,'Arnaldo CÃ©sar Coelho','Brazil'),(10,'Sergio Gonella','Italy'),(11,'Jack Taylor','England'),(12,'Rudi Glockner','East Germany'),(13,'Gottfried Dienst','Switzerland'),(14,'Nikolay Latyshev','URSS'),(15,'Maurice Guigue','France'),(16,'William Ling','England'),(17,'George Reader','England'),(18,'Georges Capdeville','France'),(19,'Ivan Eklind','Sweden'),(20,'John Langenus','Belgium'),(21,'Kim Young-Joo','South Korea'),(22,'Anders Frisk','Sweden'),(23,'Gamal Al-Ghandour','Egypt'),(24,'Peter Prendergast','Jamaica'),(25,'Felipe Ramos','Mexico'),(26,'Kim Milton Nielsen','Denmark'),(27,'Ubaldo Aquino','Paraguay'),(28,'Lopez Nieto','Spain'),(29,'Carlos Batres','Guatemala'),(30,'Hugh Dallas','Scotland'),(31,'Urs Meier','Switzerland'),(32,'Saad Al-Fadhli','Kuwait'),(33,'Toru Kamikawa','Japan'),(34,'Carlos Simon','Brazil'),(35,'Jorge Larrionda','Uruguay'),(36,'Benito Archundia','Mexico'),(37,'Medina Cantalejo','Spain'),(38,'Frank de Bleeckere','Belgium'),(39,'Valentin Ivanov','Russia'),(40,'Roberto Rosetti','Italy'),(41,'Lubos Michel','Slovakia'),(42,'Massimo Busacca','Switzerland'),(43,'Oscar Ruiz','Colombia'),(44,'Byron Moreno','Ecuador'),(45,'Ali Bujsaim','United Arab Emirates'),(46,'Philip Don','England'),(47,'Jamal Al Sharif','Syria'),(48,'Arturo Brizio Carter','Mexico'),(49,'Jose Antonio Wright','Brazil'),(50,'Michel Vautrot','France'),(51,'Kurt Rothlisberger','Switzerland'),(52,'Marco Rodriguez','Mexico'),(53,'Mario van der Ende','Netherlands'),(54,'Esfandiar Baharmast','United States of America'),(55,'Marcio Rezende de Freitas','Brazil'),(56,'Pirom Un-prasert','Thailand'),(57,'Jose Maria Garcia-Aranda','Spain'),(58,'Stephane Lannoy','France');
/*!40000 ALTER TABLE `referee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:16
