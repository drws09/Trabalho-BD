CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stadium`
--

DROP TABLE IF EXISTS `stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stadium` (
  `id_stadium` int NOT NULL,
  `name` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `capacity` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  PRIMARY KEY (`id_stadium`),
  KEY `city_id` (`city_id`),
  CONSTRAINT `stadium_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `city` (`id_city`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stadium`
--

LOCK TABLES `stadium` WRITE;
/*!40000 ALTER TABLE `stadium` DISABLE KEYS */;
INSERT INTO `stadium` VALUES (0,'Olympiastadion',72000,0),(1,'Allianz Arena',66000,1),(2,'Signal Iduna Park',65000,2),(3,'Gottlieb-Daimler-Stadion',52000,3),(4,'Arena AufSchalke',52000,4),(5,'AOL Arena',50000,5),(6,'Commerzbank-Arena',48000,6),(7,'Fritz-Walter-Stadion',46000,7),(8,'RheinEnergieStadion',45000,8),(9,'AWD-Arena',43000,9),(10,'Zentralstadion',43000,10),(11,'easyCredit-Stadion',41000,11),(12,'Deagu World Cup Stadium',68014,12),(13,'Seoul World Cup Stadium',63961,13),(14,'Busan Asiad Stadium',55982,14),(15,'Incheon World Cup Stadium',52179,15),(16,'Ulsan Munsu Football Stadium',43550,16),(17,'Suwon World Cup Stadium',43188,17),(18,'Gwangju World Cup Stadium',42880,18),(19,'Jeonju World Cup Stadium',42391,19),(20,'Jeju World Cup Stadium',42256,20),(21,'Daejeon World Cup Stadium',40407,21),(22,'International Stadium Yokohama',72327,22),(23,'Saitama Stadium',63000,23),(24,'Shizuoka Stadium ECOPA',50600,24),(25,'Nagai Stadium',50000,25),(26,'Miyagi Stadium',49000,26),(27,'Oita Stadium',43000,27),(28,'Niigata Stadium',42300,28),(29,'Kashima Stadium',42000,29),(30,'Kobe Wing Stadium',42000,30),(31,'Sapporo Dome',42000,31),(32,'Stade de France',80000,32),(33,'Stade Velodrome',60000,33),(34,'Parc des Princes',48875,34),(35,'Stade de Gerland',44000,35),(36,'Stade Felix-Bollaert',41300,36),(37,'Stade de la Beaujoire',39500,37),(38,'Stadium de Toulouse',37000,38),(39,'Stade Geoffroy-Guichard',36000,39),(40,'Parc Lescure',35200,40),(41,'Stade de la Mosson',34000,41),(42,'Rose Bowl',94194,42),(43,'Stanford Stadium',84147,43),(44,'Pontiac Silverdome',77557,44),(45,'Giants Stadium',76322,45),(46,'Cotton Bowl',64000,46),(47,'Soldier Field',63160,47),(48,'Citrus Bowl',62387,48),(49,'Foxboro Stadium',54456,49),(50,'Robert F. Kennedy Memorial Stadium',53121,50),(51,'Soccer City',84490,51),(52,'Maracana',74738,52),(53,'Luzhniki Stadium',78011,53),(54,'Stadio Olimpico',73603,54),(55,'Estadio Azteca',114600,55),(56,'Santiago Bernabeu',90089,56),(57,'Estadio Monumental',74624,57),(58,'Olympiastadion',77573,1),(59,'Wembley Stadium',98600,58),(60,'Estadio Nacional',66660,59),(61,'Rasunda Stadium',52400,60),(62,'Wankdorf Stadium',64600,61),(63,'Stade Olympique de Colombes',60000,62),(64,'Stadio Nazionale PNF',47300,54),(65,'Estadio Centenario',90000,63),(66,'Stadio delle Alpi',69041,64),(67,'Stadio San Paolo',60240,65),(68,'Stadio Comunale di Firenze',47282,66);
/*!40000 ALTER TABLE `stadium` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:17
