CREATE DATABASE  IF NOT EXISTS `world_cups` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `world_cups`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: world_cups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `extra_time`
--

DROP TABLE IF EXISTS `extra_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extra_time` (
  `id_extra_time` int NOT NULL,
  `game_id` int DEFAULT NULL,
  `home_score` smallint DEFAULT NULL,
  `away_score` smallint DEFAULT NULL,
  PRIMARY KEY (`id_extra_time`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `extra_time_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`id_game`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extra_time`
--

LOCK TABLES `extra_time` WRITE;
/*!40000 ALTER TABLE `extra_time` DISABLE KEYS */;
INSERT INTO `extra_time` VALUES (0,1,0,0),(1,2,0,1),(2,3,1,0),(3,6,0,0),(4,10,2,0),(5,13,2,0),(6,19,1,0),(7,40,0,2),(8,47,0,0),(9,48,0,0),(10,49,1,0),(11,50,0,0),(12,51,0,0),(13,52,0,1),(14,53,0,0),(15,54,1,0),(16,55,0,1),(17,56,0,0),(18,57,0,0),(19,58,0,0),(20,59,1,0),(21,60,1,1),(22,61,0,0),(23,62,0,1),(24,63,0,0),(25,64,0,0),(26,65,0,0);
/*!40000 ALTER TABLE `extra_time` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:18:16
